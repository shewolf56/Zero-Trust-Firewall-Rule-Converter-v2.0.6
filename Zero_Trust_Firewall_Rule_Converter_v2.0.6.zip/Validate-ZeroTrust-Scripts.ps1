﻿#requires -Version 5.1
[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSCommandPath
$files = @('ZeroTrust-Firewall.ps1','ZeroTrust-Policy.ps1','Validate-ZeroTrust-Scripts.ps1')
$configFiles = @('Approved-Source-Rules.csv','Approved-Outbound-Allow-Rules.csv','Trusted-Executable-SHA256.csv','Approved-Executable-SHA256.csv','ZT-Rule-Executable-SHA256.csv')
$failed = $false
foreach ($file in $files) {
    $path = Join-Path $root $file
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        Write-Host ("[FAIL] Missing script: {0}" -f $path) -ForegroundColor Red
        $failed = $true
        continue
    }
    $tokens = $null
    $parseErrors = $null
    [System.Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$parseErrors) | Out-Null
    if ($parseErrors.Length -gt 0) {
        Write-Host ("[FAIL] PowerShell 5.1 parser: {0}" -f $file) -ForegroundColor Red
        foreach ($errorRecord in $parseErrors) {
            Write-Host ("  Line {0}, column {1}: {2}" -f $errorRecord.Extent.StartLineNumber,$errorRecord.Extent.StartColumnNumber,$errorRecord.Message) -ForegroundColor Red
        }
        $failed = $true
    }
    else { Write-Host ("[PASS] PowerShell 5.1 parser: {0}" -f $file) -ForegroundColor Green }
}
foreach ($file in $configFiles) {
    $path = Join-Path (Join-Path $root 'Config') $file
    if (Test-Path -LiteralPath $path -PathType Leaf) { Write-Host ("[PASS] Config template: {0}" -f $file) -ForegroundColor Green }
    else { Write-Host ("[FAIL] Missing config template: {0}" -f $file) -ForegroundColor Red; $failed = $true }
}
if ($failed) {
    Write-Host '[ERROR] PowerShell/config validation failed.' -ForegroundColor Red
    exit 1
}
Write-Host 'All packaged PowerShell scripts and required configuration templates passed validation.' -ForegroundColor Green
exit 0
