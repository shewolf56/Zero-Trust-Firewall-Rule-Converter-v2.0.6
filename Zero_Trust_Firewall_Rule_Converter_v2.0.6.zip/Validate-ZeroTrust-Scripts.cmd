﻿@echo off
setlocal
cd /d "%~dp0"
title Validate Zero Trust Firewall Rule Converter v2.0.6
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Validate-ZeroTrust-Scripts.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo [ERROR] Validation failed with exit code %RC%.
pause
exit /b %RC%
