﻿#requires -Version 5.1
<#
.VERSION 2.0.6
.SYNOPSIS
    Explicit Windows Firewall profile policy controls with outbound-Allow approval gate.
.DESCRIPTION
    Audit is read-only. Outbound Block requires a full backup, a current ActiveStore
    audit, a fingerprint-and-reason approval for every enabled outbound Allow not
    created by this importer's exact ZT- group, and exact typed confirmation.
    OverrideBlockRules exceptions are
    always rejected. This script is never run automatically by the rule importer.
#>
[CmdletBinding()]
param(
    [ValidateSet('Audit','EnableOutboundBlock','SetLocalFirewallRules')]
    [string]$Mode = 'Audit',
    [ValidateSet('Keep','Enable','Disable')]
    [string]$LocalFirewallRules = 'Keep'
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
if (-not (Test-IsAdministrator)) {
    $psExe = Join-Path $PSHOME 'powershell.exe'
    $quotedScript = '"' + $PSCommandPath.Replace('"','\"') + '"'
    $argLine = '-NoLogo -NoProfile -ExecutionPolicy Bypass -File {0} -Mode {1} -LocalFirewallRules {2}' -f $quotedScript,$Mode,$LocalFirewallRules
    try {
        $child = Start-Process -FilePath $psExe -ArgumentList $argLine -Verb RunAs -Wait -PassThru
        exit $child.ExitCode
    }
    catch {
        Write-Host ('UAC elevation failed or was cancelled: ' + $_.Exception.Message) -ForegroundColor Red
        exit 2
    }
}

Import-Module NetSecurity -ErrorAction Stop
$root = Split-Path -Parent $PSCommandPath
$backupDir = Join-Path $root 'Backups'
$logDir = Join-Path $root 'Logs'
$configDir = Join-Path $root 'Config'
foreach ($directory in @($backupDir,$logDir,$configDir)) {
    if (-not (Test-Path -LiteralPath $directory -PathType Container)) {
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
    }
}
$stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$auditPath = Join-Path $logDir ("Outbound-Allow-Audit_{0}.csv" -f $stamp)
$approvalPath = Join-Path $configDir 'Approved-Outbound-Allow-Rules.csv'

function Get-FilterValues {
    param([AllowNull()][object]$Object,[Parameter(Mandatory=$true)][string]$Property,[string]$DefaultValue='Any')
    $items = New-Object 'System.Collections.Generic.List[string]'
    if ($null -ne $Object -and $null -ne $Object.PSObject.Properties[$Property]) {
        foreach ($entry in @($Object.$Property)) {
            if ($null -eq $entry) { continue }
            foreach ($nested in @($entry)) {
                if ($null -eq $nested) { continue }
                $value = ([string]$nested).Trim()
                if ($value.Length -gt 0) { $items.Add($value) }
            }
        }
    }
    if ($items.Count -eq 0) { return @($DefaultValue) }
    return @($items.ToArray() | Sort-Object -Unique)
}

function Get-Filter {
    param([Parameter(Mandatory=$true)][object]$Rule,[Parameter(Mandatory=$true)][string]$CmdletName)
    $result = @(& $CmdletName -AssociatedNetFirewallRule $Rule -ErrorAction Stop)
    if ($result.Length -gt 1) { throw ("Unexpected multiple filters from {0} for rule {1}." -f $CmdletName,$Rule.Name) }
    if ($result.Length -eq 0) { return $null }
    return $result[0]
}

function Get-CanonicalProtocol {
    param([AllowNull()][object]$Values)
    $normalized = New-Object 'System.Collections.Generic.List[string]'
    foreach ($value in @(Get-FilterValues -Object ([pscustomobject]@{Value=$Values}) -Property 'Value')) {
        switch ([string]$value) {
            '6' { $normalized.Add('TCP'); break }
            '17' { $normalized.Add('UDP'); break }
            '1' { $normalized.Add('ICMPv4'); break }
            '58' { $normalized.Add('ICMPv6'); break }
            '256' { $normalized.Add('Any'); break }
            default { $normalized.Add([string]$value) }
        }
    }
    return @($normalized.ToArray() | Sort-Object -Unique)
}

function Get-RuleData {
    param([Parameter(Mandatory=$true)][object]$Rule)
    $app = Get-Filter -Rule $Rule -CmdletName 'Get-NetFirewallApplicationFilter'
    $service = Get-Filter -Rule $Rule -CmdletName 'Get-NetFirewallServiceFilter'
    $port = Get-Filter -Rule $Rule -CmdletName 'Get-NetFirewallPortFilter'
    $address = Get-Filter -Rule $Rule -CmdletName 'Get-NetFirewallAddressFilter'
    $interface = Get-Filter -Rule $Rule -CmdletName 'Get-NetFirewallInterfaceFilter'
    $interfaceType = Get-Filter -Rule $Rule -CmdletName 'Get-NetFirewallInterfaceTypeFilter'
    $security = Get-Filter -Rule $Rule -CmdletName 'Get-NetFirewallSecurityFilter'
    $data = [ordered]@{
        Name = [string]$Rule.Name
        Enabled = [string]$Rule.Enabled
        Direction = [string]$Rule.Direction
        Action = [string]$Rule.Action
        Profile = @(Get-FilterValues -Object ([pscustomobject]@{Value=$Rule.Profile}) -Property 'Value')
        EdgeTraversalPolicy = [string]$Rule.EdgeTraversalPolicy
        LooseSourceMapping = [string]$Rule.LooseSourceMapping
        LocalOnlyMapping = [string]$Rule.LocalOnlyMapping
        Owner = [string]$Rule.Owner
        Program = @(Get-FilterValues -Object $app -Property 'Program')
        Package = @(Get-FilterValues -Object $app -Property 'Package')
        Service = @(Get-FilterValues -Object $service -Property 'Service')
        Protocol = @(Get-CanonicalProtocol -Values (Get-FilterValues -Object $port -Property 'Protocol'))
        LocalPort = @(Get-FilterValues -Object $port -Property 'LocalPort')
        RemotePort = @(Get-FilterValues -Object $port -Property 'RemotePort')
        IcmpType = @(Get-FilterValues -Object $port -Property 'IcmpType')
        DynamicTarget = @(Get-FilterValues -Object $port -Property 'DynamicTarget')
        LocalAddress = @(Get-FilterValues -Object $address -Property 'LocalAddress')
        RemoteAddress = @(Get-FilterValues -Object $address -Property 'RemoteAddress')
        RemoteDynamicKeywordAddresses = @(Get-FilterValues -Object $address -Property 'RemoteDynamicKeywordAddresses')
        InterfaceAlias = @(Get-FilterValues -Object $interface -Property 'InterfaceAlias')
        InterfaceType = @(Get-FilterValues -Object $interfaceType -Property 'InterfaceType')
        Authentication = [string]$(if ($null -ne $security) { $security.Authentication } else { 'NotRequired' })
        Encryption = [string]$(if ($null -ne $security) { $security.Encryption } else { 'NotRequired' })
        OverrideBlockRules = [string]$(if ($null -ne $security) { $security.OverrideBlockRules } else { 'False' })
        LocalUser = @(Get-FilterValues -Object $security -Property 'LocalUser')
        RemoteUser = @(Get-FilterValues -Object $security -Property 'RemoteUser')
        RemoteMachine = @(Get-FilterValues -Object $security -Property 'RemoteMachine')
    }
    return [pscustomobject]$data
}

function Get-RuleFingerprint {
    param([Parameter(Mandatory=$true)][object]$Data)
    $json = $Data | ConvertTo-Json -Depth 8 -Compress
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes($json)
        return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','').ToUpperInvariant()
    }
    finally { $sha.Dispose() }
}

function Get-OutboundAllowAudit {
    $rules = @(Get-NetFirewallRule -PolicyStore ActiveStore -ErrorAction Stop | Where-Object {
        [string]$_.Enabled -eq 'True' -and [string]$_.Direction -eq 'Outbound' -and [string]$_.Action -eq 'Allow'
    })
    $rows = New-Object 'System.Collections.Generic.List[object]'
    foreach ($rule in $rules) {
        $data = Get-RuleData -Rule $rule
        $identity = @()
        foreach ($field in @('Program','Package','Service')) {
            $values = @($data.$field | Where-Object { $_ -ne 'Any' })
            if ($values.Length -gt 0) { $identity += (($field + '=') + ($values -join ';')) }
        }
        $rows.Add([pscustomobject]@{
            Name = [string]$rule.Name
            DisplayName = [string]$rule.DisplayName
            Group = [string]$rule.Group
            ApplicationIdentity = ($identity -join '; ')
            Protocol = ($data.Protocol -join ';')
            LocalPort = ($data.LocalPort -join ';')
            RemotePort = ($data.RemotePort -join ';')
            LocalAddress = ($data.LocalAddress -join ';')
            RemoteAddress = ($data.RemoteAddress -join ';')
            InterfaceAlias = ($data.InterfaceAlias -join ';')
            EdgeTraversalPolicy = $data.EdgeTraversalPolicy
            LooseSourceMapping = $data.LooseSourceMapping
            LocalOnlyMapping = $data.LocalOnlyMapping
            Owner = $data.Owner
            OverrideBlockRules = $data.OverrideBlockRules
            IsZTManaged = ([string]$rule.Name).StartsWith('ZT-',[StringComparison]::OrdinalIgnoreCase) -and [string]$rule.Group -eq 'ZeroTrust - Managed Rules'
            Fingerprint = Get-RuleFingerprint -Data $data
        })
    }
    return $rows.ToArray()
}

function Save-PolicyBackup {
    $path = Join-Path $backupDir ("WindowsFirewall_PolicyChange_{0}.wfw" -f (Get-Date -Format 'yyyyMMdd_HHmmss_fff'))
    $netsh = Join-Path $env:SystemRoot 'System32\netsh.exe'
    & $netsh advfirewall export $path | Out-Null
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $path -PathType Leaf)) { throw 'Could not export the current Windows Firewall policy.' }
    Write-Host ("Full firewall backup saved: {0}" -f $path) -ForegroundColor Green
    return $path
}

function Show-PolicyAudit {
    Write-Host "`nWindows Firewall profile state:" -ForegroundColor Cyan
    Get-NetFirewallProfile | Select-Object Name,Enabled,DefaultInboundAction,DefaultOutboundAction,AllowInboundRules,AllowLocalFirewallRules,AllowLocalIPsecRules | Format-Table -AutoSize | Out-Host
    $rows = @(Get-OutboundAllowAudit)
    if ($rows.Length -gt 0) { $rows | Export-Csv -LiteralPath $auditPath -NoTypeInformation -Encoding UTF8 }
    else { 'Name,DisplayName,Group,ApplicationIdentity,Protocol,LocalPort,RemotePort,LocalAddress,RemoteAddress,InterfaceAlias,EdgeTraversalPolicy,LooseSourceMapping,LocalOnlyMapping,Owner,OverrideBlockRules,IsZTManaged,Fingerprint' | Set-Content -LiteralPath $auditPath -Encoding UTF8 }
    Write-Host ("Enabled ActiveStore outbound Allow rules: {0}" -f $rows.Length) -ForegroundColor Cyan
    Write-Host ("Fingerprint audit saved: {0}" -f $auditPath) -ForegroundColor Cyan
    return $rows
}

function Ensure-ApprovalTemplate {
    if (-not (Test-Path -LiteralPath $approvalPath -PathType Leaf)) {
        'Name,Fingerprint,Reason' | Set-Content -LiteralPath $approvalPath -Encoding UTF8
        Write-Host ("Created empty approval template: {0}" -f $approvalPath) -ForegroundColor Yellow
    }
}

function Test-OutboundAllowApprovals {
    param([object[]]$Rows)
    Ensure-ApprovalTemplate
    $approvals = @(Import-Csv -LiteralPath $approvalPath -ErrorAction Stop)
    $external = @($Rows | Where-Object { -not $_.IsZTManaged })
    $override = @($Rows | Where-Object { [string]$_.OverrideBlockRules -eq 'True' })
    if ($override.Length -gt 0) {
        Write-Host 'HARD STOP: enabled outbound Allow rule(s), including imported rules, have OverrideBlockRules=True:' -ForegroundColor Red
        foreach ($row in $override) { Write-Host ("  {0} | {1}" -f $row.Name,$row.DisplayName) -ForegroundColor Red }
        throw 'Resolve every enabled outbound Allow with OverrideBlockRules=True, including imported rules, before enabling outbound Block.'
    }
    $unapproved = New-Object 'System.Collections.Generic.List[object]'
    foreach ($row in $external) {
        $match = @($approvals | Where-Object {
            [string]$_.Name -ceq [string]$row.Name -and
            [string]$_.Fingerprint -ceq [string]$row.Fingerprint -and
            -not [string]::IsNullOrWhiteSpace([string]$_.Reason)
        } | Select-Object -First 1)
        if ($match.Length -eq 0) { $unapproved.Add($row) }
    }
    if ($unapproved.Count -gt 0) {
        Write-Host ("Outbound Block preflight stopped: {0} enabled outbound Allow rule(s) are not individually approved." -f $unapproved.Count) -ForegroundColor Red
        Write-Host ("Review: {0}" -f $auditPath) -ForegroundColor Yellow
        Write-Host ("After review, add exact Name + Fingerprint + a meaningful Reason to: {0}" -f $approvalPath) -ForegroundColor Yellow
        Write-Host 'Any source-rule change invalidates its prior fingerprint approval.' -ForegroundColor Yellow
        throw 'Outbound Allow approval gate did not pass. Profile defaults were not changed.'
    }
    Write-Host ("Outbound Allow approval gate passed ({0} rule(s) outside the importer group approved; no OverrideBlockRules bypasses found)." -f $external.Length) -ForegroundColor Green
}

$profiles = @(Get-NetFirewallProfile)
if ($profiles.Length -eq 0) { throw 'No firewall profiles were returned.' }
$previousOutbound = @{}
$previousLocal = @{}
foreach ($profile in $profiles) {
    $previousOutbound[[string]$profile.Name] = [string]$profile.DefaultOutboundAction
    $previousLocal[[string]$profile.Name] = [string]$profile.AllowLocalFirewallRules
}

if ($Mode -eq 'Audit') {
    $null = Show-PolicyAudit
    Write-Host 'Audit is read-only. No policy settings were changed.' -ForegroundColor Green
    exit 0
}

if ($Mode -eq 'EnableOutboundBlock') {
    $rows = @(Show-PolicyAudit)
    $managed = @(Get-NetFirewallRule -PolicyStore ActiveStore -ErrorAction Stop | Where-Object {
        ([string]$_.Name).StartsWith('ZT-',[StringComparison]::OrdinalIgnoreCase) -and
        [string]$_.Group -eq 'ZeroTrust - Managed Rules' -and
        [string]$_.Enabled -eq 'True' -and [string]$_.Direction -eq 'Outbound' -and [string]$_.Action -eq 'Allow'
    })
    if ($managed.Length -eq 0) { throw 'No enabled ZT- outbound Allow rules from this importer were found.' }
    Test-OutboundAllowApprovals -Rows $rows
    Write-Host 'WARNING: outbound Block can interrupt apps, services, VPN, DNS and Windows updates when exceptions are missing.' -ForegroundColor Yellow
    Write-Host 'All external outbound Allow rules must be reviewed and fingerprint-approved first.' -ForegroundColor Yellow
    $null = Save-PolicyBackup
    $confirmation = Read-Host 'Type ENABLE OUTBOUND BLOCK to continue'
    if ($confirmation -cne 'ENABLE OUTBOUND BLOCK') { Write-Host 'Cancelled; no settings changed.' -ForegroundColor Yellow; exit 0 }
    try {
        Set-NetFirewallProfile -Name Domain,Private,Public -DefaultOutboundAction Block -ErrorAction Stop
        $check = @(Get-NetFirewallProfile)
        $notBlocked = @($check | Where-Object { [string]$_.DefaultOutboundAction -ne 'Block' })
        if ($notBlocked.Length -gt 0) { throw ('Outbound Block verification failed for: ' + ($notBlocked.Name -join ', ')) }
        Write-Host 'Outbound default action is Block on all profiles.' -ForegroundColor Green
    }
    catch {
        Write-Host ('Policy update failed; attempting to restore previous outbound actions: ' + $_.Exception.Message) -ForegroundColor Red
        foreach ($name in $previousOutbound.Keys) {
            try { Set-NetFirewallProfile -Name $name -DefaultOutboundAction $previousOutbound[$name] -ErrorAction Stop }
            catch { Write-Host ("Rollback failed for profile {0}: {1}" -f $name,$_.Exception.Message) -ForegroundColor Red }
        }
        throw
    }
}
elseif ($Mode -eq 'SetLocalFirewallRules') {
    if ($LocalFirewallRules -eq 'Keep') { throw 'Choose -LocalFirewallRules Enable or Disable for this mode.' }
    if ($LocalFirewallRules -eq 'Disable') {
        Write-Host 'WARNING: disabling local firewall-rule merging can make local ZT- rules ineffective.' -ForegroundColor Yellow
    }
    $null = Save-PolicyBackup
    $confirmation = Read-Host 'Type CHANGE LOCAL RULE MERGING to continue'
    if ($confirmation -cne 'CHANGE LOCAL RULE MERGING') { Write-Host 'Cancelled; no settings changed.' -ForegroundColor Yellow; exit 0 }
    $valueText = if ($LocalFirewallRules -eq 'Enable') { 'True' } else { 'False' }
    try {
        Set-NetFirewallProfile -Name Domain,Private,Public -AllowLocalFirewallRules $valueText -ErrorAction Stop
        $check = @(Get-NetFirewallProfile)
        $bad = @($check | Where-Object { [string]$_.AllowLocalFirewallRules -ne $valueText })
        if ($bad.Length -gt 0) { throw ('Local-rule merging verification failed for: ' + ($bad.Name -join ', ')) }
        Write-Host ("AllowLocalFirewallRules set to {0} for all profiles." -f $valueText) -ForegroundColor Green
    }
    catch {
        Write-Host ('Policy update failed; attempting rollback: ' + $_.Exception.Message) -ForegroundColor Red
        foreach ($name in $previousLocal.Keys) {
            try { Set-NetFirewallProfile -Name $name -AllowLocalFirewallRules $previousLocal[$name] -ErrorAction Stop }
            catch { Write-Host ("Rollback failed for profile {0}: {1}" -f $name,$_.Exception.Message) -ForegroundColor Red }
        }
        throw
    }
}

Write-Host "`nFinal Windows Firewall profile state:" -ForegroundColor Cyan
Get-NetFirewallProfile | Select-Object Name,Enabled,DefaultInboundAction,DefaultOutboundAction,AllowLocalFirewallRules | Format-Table -AutoSize | Out-Host
