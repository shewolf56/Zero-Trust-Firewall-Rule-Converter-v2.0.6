﻿@echo off
setlocal
cd /d "%~dp0"
title Zero Trust Firewall Rule Converter v2.0.6
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0ZeroTrust-Converter.ps1" -Mode Menu
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" echo [ERROR] Firewall manager returned exit code %RC%.
pause
exit /b %RC%
