﻿#requires -Version 5.1
<#
.VERSION
    2.0.6
.SYNOPSIS
    Universal, pathless Windows Firewall rule discovery and ZeroTrust importer.
.DESCRIPTION
    Discovers application- and service-scoped rules from the local PersistentStore.
    Creates verified ZT- rules from a staged, restorable snapshot of existing
    application/service firewall rules. The migration has three explicit stages:
    1. Export the full firewall policy and a structured per-rule migration plan.
    2. Delete only app/service source rules captured, fingerprinted, hash-checked
       and approved in that plan. Unsupported or unhashable rules are preserved.
    3. Recreate the approved rules from the immutable snapshot under the ZT- prefix.
    No app path, install directory, VPN adapter or vendor-specific app list is used. Broad Allow rules are held for
    review. Every file-backed executable is SHA-256 checked before deployment. First-seen hashes require
    explicit operator enrollment during stage 1 backup; changed hashes require exact path+hash
    approval. A fresh hash is checked immediately before rule creation. Windows Defender Firewall does not enforce those hashes.
    Deployment does not change profile default actions.
#>
[CmdletBinding()]
param(
    [ValidateSet('Menu','Preview','Convert','Audit','Backup','DeleteOldRules','CreateZTRules','Restore','RemoveImported','Validate')]
    [string]$Mode = 'Menu',
    [string]$BackupFile
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

$script:Version = '2.0.6'
$script:Root = Split-Path -Parent $PSCommandPath
$script:LogDir = Join-Path $script:Root 'Logs'
$script:BackupDir = Join-Path $script:Root 'Backups'
$script:ReportDir = Join-Path $script:Root 'Reports'
$script:ConfigDir = Join-Path $script:Root 'Config'
$script:SourceApprovalPath = Join-Path $script:ConfigDir 'Approved-Source-Rules.csv'
$script:ExecutableBaselinePath = Join-Path $script:ConfigDir 'Trusted-Executable-SHA256.csv'
$script:ExecutableApprovalPath = Join-Path $script:ConfigDir 'Approved-Executable-SHA256.csv'
$script:RuleHashManifestPath = Join-Path $script:ConfigDir 'ZT-Rule-Executable-SHA256.csv'
$script:RulePrefix = 'ZT-'
$script:ManagedGroup = 'ZeroTrust - Managed Rules'
$script:MigrationPlanPointerPath = Join-Path $script:ConfigDir 'Current-Migration-Plan.txt'
$script:RetireSourceRules = $false
$script:Stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
$script:TranscriptPath = Join-Path $script:LogDir ("ZeroTrust-Firewall_{0}.log" -f $script:Stamp)
$script:InventoryPath = Join-Path $script:ReportDir ("Executable-SHA256_{0}.csv" -f $script:Stamp)
$script:IntegrityAuditPath = Join-Path $script:ReportDir ("Executable-Integrity-Audit_{0}.csv" -f $script:Stamp)
$script:ResultsPath = Join-Path $script:ReportDir ("Existing-Rules-Conversion_{0}.csv" -f $script:Stamp)
$script:HashInventory = New-Object 'System.Collections.Generic.List[object]'
$script:HashSeen = @{}
$script:IntegrityAudit = New-Object 'System.Collections.Generic.List[object]'
$script:TrustedExecutableRows = @()
$script:TrustedExecutableHashes = @{}
$script:ExecutableHashApprovals = @{}
$script:Stats = [ordered]@{ Discovered=0; Eligible=0; Created=0; Updated=0; Unchanged=0; RetiredSources=0; Review=0; Skipped=0; Errors=0; Removed=0 }

function Write-Status {
    param(
        [Parameter(Mandatory=$true)][string]$Message,
        [ValidateSet('Gray','Green','Yellow','Red','Cyan','White','DarkGray')][string]$Color = 'Gray'
    )
    Write-Host $Message -ForegroundColor $Color
}

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Start-ElevatedCopy {
    param([string]$RequestedMode,[string]$RequestedBackupFile)
    $psExe = Join-Path $PSHOME 'powershell.exe'
    $quotedScript = '"' + $PSCommandPath.Replace('"','\"') + '"'
    $argLine = '-NoLogo -NoProfile -ExecutionPolicy Bypass -File {0} -Mode {1}' -f $quotedScript,$RequestedMode
    if (-not [string]::IsNullOrWhiteSpace($RequestedBackupFile)) {
        $quotedBackup = '"' + $RequestedBackupFile.Replace('"','\"') + '"'
        $argLine += ' -BackupFile ' + $quotedBackup
    }
    $child = Start-Process -FilePath $psExe -ArgumentList $argLine -Verb RunAs -Wait -PassThru
    exit $child.ExitCode
}

function Get-PropertyValue {
    param([AllowNull()][object]$Object,[Parameter(Mandatory=$true)][string]$Name,[AllowNull()][object]$DefaultValue)
    if ($null -ne $Object -and $null -ne $Object.PSObject.Properties[$Name]) {
        $value = $Object.$Name
        if ($null -ne $value) { return $value }
    }
    return $DefaultValue
}

function Get-FilterValues {
    param([AllowNull()][object]$Object,[Parameter(Mandatory=$true)][string]$Property,[string]$DefaultValue='Any')
    $items = New-Object 'System.Collections.Generic.List[string]'
    if ($null -ne $Object -and $null -ne $Object.PSObject.Properties[$Property]) {
        foreach ($entry in @($Object.$Property)) {
            if ($null -eq $entry) { continue }
            if ($entry -is [System.Array]) {
                foreach ($nested in $entry) {
                    if ($null -ne $nested) {
                        $value = ([string]$nested).Trim()
                        if ($value.Length -gt 0) { $items.Add($value) }
                    }
                }
            }
            else {
                $value = ([string]$entry).Trim()
                if ($value.Length -gt 0) { $items.Add($value) }
            }
        }
    }
    if ($items.Count -eq 0) { return @($DefaultValue) }
    return $items.ToArray()
}

function Get-ScalarValue {
    param([AllowNull()][object]$Object,[Parameter(Mandatory=$true)][string]$Property,[string]$DefaultValue='')
    $values = @(Get-FilterValues -Object $Object -Property $Property -DefaultValue $DefaultValue)
    if ($values.Length -eq 0) { return $DefaultValue }
    if ($values.Length -gt 1) { return ($values -join ',') }
    return [string]$values[0]
}

function Get-AssociatedFilter {
    param([Parameter(Mandatory=$true)][object]$Rule,[Parameter(Mandatory=$true)][ValidateSet('Application','Service','Port','Address','Interface','InterfaceType','Security')][string]$Kind)
    $cmdlet = switch ($Kind) {
        'Application' { 'Get-NetFirewallApplicationFilter' }
        'Service' { 'Get-NetFirewallServiceFilter' }
        'Port' { 'Get-NetFirewallPortFilter' }
        'Address' { 'Get-NetFirewallAddressFilter' }
        'Interface' { 'Get-NetFirewallInterfaceFilter' }
        'InterfaceType' { 'Get-NetFirewallInterfaceTypeFilter' }
        'Security' { 'Get-NetFirewallSecurityFilter' }
    }
    $result = @(& $cmdlet -AssociatedNetFirewallRule $Rule -ErrorAction Stop)
    if ($result.Length -gt 1) { throw ("Unexpected multiple {0} filters for rule '{1}'." -f $Kind,$Rule.Name) }
    if ($result.Length -eq 0) { return $null }
    return $result[0]
}

function ConvertTo-NormalizedValues {
    param([AllowNull()][object]$Values,[string]$DefaultValue='Any')
    $list = New-Object 'System.Collections.Generic.List[string]'
    if ($null -ne $Values) {
        foreach ($entry in @($Values)) {
            if ($null -eq $entry) { continue }
            foreach ($nested in @($entry)) {
                if ($null -eq $nested) { continue }
                $value = ([string]$nested).Trim()
                if ($value.Length -gt 0) { $list.Add($value.ToLowerInvariant()) }
            }
        }
    }
    if ($list.Count -eq 0) { return @($DefaultValue.ToLowerInvariant()) }
    return @($list.ToArray() | Sort-Object -Unique)
}


function ConvertTo-NormalizedEnumValues {
    param([AllowNull()][object]$Values,[string]$DefaultValue='Any')
    $parts = New-Object 'System.Collections.Generic.List[string]'
    foreach ($entry in @($Values)) {
        if ($null -eq $entry) { continue }
        foreach ($piece in ([string]$entry -split '\s*,\s*')) {
            $value = $piece.Trim()
            if ($value.Length -gt 0) { $parts.Add($value.ToLowerInvariant()) }
        }
    }
    if ($parts.Count -eq 0) { return @($DefaultValue.ToLowerInvariant()) }
    return @($parts.ToArray() | Sort-Object -Unique)
}

function ConvertTo-NormalizedProtocolValues {
    param([AllowNull()][object]$Values)
    $canonical = New-Object 'System.Collections.Generic.List[string]'
    foreach ($value in @(ConvertTo-NormalizedValues -Values $Values)) {
        switch ([string]$value) {
            '6' { $canonical.Add('tcp'); break }
            '17' { $canonical.Add('udp'); break }
            '1' { $canonical.Add('icmpv4'); break }
            '58' { $canonical.Add('icmpv6'); break }
            '256' { $canonical.Add('any'); break }
            default { $canonical.Add([string]$value) }
        }
    }
    return @($canonical.ToArray() | Sort-Object -Unique)
}

function Get-RuleSnapshot {
    param([Parameter(Mandatory=$true)][object]$Rule)
    $app = Get-AssociatedFilter -Rule $Rule -Kind Application
    $service = Get-AssociatedFilter -Rule $Rule -Kind Service
    $port = Get-AssociatedFilter -Rule $Rule -Kind Port
    $address = Get-AssociatedFilter -Rule $Rule -Kind Address
    $interface = Get-AssociatedFilter -Rule $Rule -Kind Interface
    $interfaceType = Get-AssociatedFilter -Rule $Rule -Kind InterfaceType
    $security = Get-AssociatedFilter -Rule $Rule -Kind Security
    $directionValue = ([string](Get-PropertyValue $Rule 'Direction' 'Outbound')).ToLowerInvariant()
    $edgeTraversalValue = 'notapplicable'
    if ($directionValue -eq 'inbound') { $edgeTraversalValue = ([string](Get-PropertyValue $Rule 'EdgeTraversalPolicy' 'Block')).ToLowerInvariant() }

    $snapshot = [ordered]@{
        Enabled = ([string](Get-PropertyValue $Rule 'Enabled' 'True')).ToLowerInvariant()
        Direction = $directionValue
        Action = ([string](Get-PropertyValue $Rule 'Action' 'Allow')).ToLowerInvariant()
        Profile = ConvertTo-NormalizedEnumValues -Values (Get-PropertyValue $Rule 'Profile' 'Any')
        Platform = ConvertTo-NormalizedValues -Values (Get-PropertyValue $Rule 'Platform' 'Any')
        Program = ConvertTo-NormalizedValues -Values (Get-PropertyValue $app 'Program' 'Any')
        Package = ConvertTo-NormalizedValues -Values (Get-PropertyValue $app 'Package' 'Any')
        Service = ConvertTo-NormalizedValues -Values (Get-PropertyValue $service 'Service' 'Any')
        Protocol = ConvertTo-NormalizedProtocolValues -Values (Get-PropertyValue $port 'Protocol' 'Any')
        LocalPort = ConvertTo-NormalizedValues -Values (Get-PropertyValue $port 'LocalPort' 'Any')
        RemotePort = ConvertTo-NormalizedValues -Values (Get-PropertyValue $port 'RemotePort' 'Any')
        IcmpType = ConvertTo-NormalizedValues -Values (Get-PropertyValue $port 'IcmpType' 'Any')
        DynamicTarget = ConvertTo-NormalizedValues -Values (Get-PropertyValue $port 'DynamicTarget' 'Any')
        LocalAddress = ConvertTo-NormalizedValues -Values (Get-PropertyValue $address 'LocalAddress' 'Any')
        RemoteAddress = ConvertTo-NormalizedValues -Values (Get-PropertyValue $address 'RemoteAddress' 'Any')
        RemoteDynamicKeywordAddresses = ConvertTo-NormalizedValues -Values (Get-PropertyValue $address 'RemoteDynamicKeywordAddresses' 'Any')
        InterfaceAlias = ConvertTo-NormalizedValues -Values (Get-PropertyValue $interface 'InterfaceAlias' 'Any')
        InterfaceType = ConvertTo-NormalizedEnumValues -Values (Get-PropertyValue $interfaceType 'InterfaceType' 'Any')
        EdgeTraversalPolicy = $edgeTraversalValue
        LooseSourceMapping = ([string](Get-PropertyValue $Rule 'LooseSourceMapping' 'False')).ToLowerInvariant()
        LocalOnlyMapping = ([string](Get-PropertyValue $Rule 'LocalOnlyMapping' 'False')).ToLowerInvariant()
        Owner = ConvertTo-NormalizedValues -Values (Get-PropertyValue $Rule 'Owner' 'Any')
        Authentication = ([string](Get-PropertyValue $security 'Authentication' 'NotRequired')).ToLowerInvariant()
        Encryption = ([string](Get-PropertyValue $security 'Encryption' 'NotRequired')).ToLowerInvariant()
        OverrideBlockRules = ([string](Get-PropertyValue $security 'OverrideBlockRules' 'False')).ToLowerInvariant()
        LocalUser = ConvertTo-NormalizedValues -Values (Get-PropertyValue $security 'LocalUser' 'Any')
        RemoteUser = ConvertTo-NormalizedValues -Values (Get-PropertyValue $security 'RemoteUser' 'Any')
        RemoteMachine = ConvertTo-NormalizedValues -Values (Get-PropertyValue $security 'RemoteMachine' 'Any')
    }
    return [pscustomobject]$snapshot
}

function Get-SnapshotFingerprint {
    param([Parameter(Mandatory=$true)][object]$Snapshot)
    $json = $Snapshot | ConvertTo-Json -Depth 8 -Compress
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes($json)
        return ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','').ToUpperInvariant()
    }
    finally { $sha.Dispose() }
}

function Get-ShortTextHash {
    param([Parameter(Mandatory=$true)][string]$Text,[int]$Length=20)
    $sha = [Security.Cryptography.SHA256]::Create()
    try {
        $bytes = [Text.Encoding]::UTF8.GetBytes($Text.ToLowerInvariant())
        $hash = ([BitConverter]::ToString($sha.ComputeHash($bytes))).Replace('-','').ToUpperInvariant()
        return $hash.Substring(0,[Math]::Min($Length,$hash.Length))
    }
    finally { $sha.Dispose() }
}

function Get-CanonicalExecutablePath {
    param([Parameter(Mandatory=$true)][string]$Path)
    $rawPath = $Path.Trim()
    if ($rawPath.Length -ge 2 -and $rawPath.StartsWith('"') -and $rawPath.EndsWith('"')) {
        $rawPath = $rawPath.Substring(1,$rawPath.Length-2)
    }
    $expanded = [Environment]::ExpandEnvironmentVariables($rawPath)
    if ([string]::IsNullOrWhiteSpace($expanded)) { throw 'Executable path is empty.' }
    try { return [IO.Path]::GetFullPath($expanded) }
    catch { throw ("Executable path cannot be normalized: {0}" -f $Path) }
}

function Initialize-ExecutableTrustStore {
    if (-not (Test-Path -LiteralPath $script:ExecutableBaselinePath -PathType Leaf)) {
        'Path,SHA256,FileSizeBytes,LastWriteTimeUtc,FirstTrustedUtc,LastVerifiedUtc,PreviousSHA256,LastApprovalReason,LastRuleSource' | Set-Content -LiteralPath $script:ExecutableBaselinePath -Encoding UTF8
    }
    if (-not (Test-Path -LiteralPath $script:ExecutableApprovalPath -PathType Leaf)) {
        'Path,SHA256,Reason' | Set-Content -LiteralPath $script:ExecutableApprovalPath -Encoding UTF8
    }
    if (-not (Test-Path -LiteralPath $script:RuleHashManifestPath -PathType Leaf)) {
        'ZTRuleName,SourceRuleName,ExecutablePath,IdentityType,SHA256,LastVerifiedUtc' | Set-Content -LiteralPath $script:RuleHashManifestPath -Encoding UTF8
    }

    $script:TrustedExecutableRows = @(Import-Csv -LiteralPath $script:ExecutableBaselinePath -ErrorAction Stop)
    $script:TrustedExecutableHashes = @{}
    foreach ($row in $script:TrustedExecutableRows) {
        if ([string]::IsNullOrWhiteSpace([string]$row.Path) -or [string]$row.SHA256 -notmatch '^[A-Fa-f0-9]{64}$') {
            throw ("Executable trust baseline contains an invalid row. Review: {0}" -f $script:ExecutableBaselinePath)
        }
        $canonical = Get-CanonicalExecutablePath -Path ([string]$row.Path)
        $key = $canonical.ToLowerInvariant()
        if ($script:TrustedExecutableHashes.ContainsKey($key)) {
            throw ("Duplicate executable path in trust baseline; refusing ambiguous trust: {0}" -f $canonical)
        }
        $script:TrustedExecutableHashes[$key] = $row
    }

    $approvalRows = @(Import-Csv -LiteralPath $script:ExecutableApprovalPath -ErrorAction Stop)
    $script:ExecutableHashApprovals = @{}
    foreach ($approval in $approvalRows) {
        if ([string]::IsNullOrWhiteSpace([string]$approval.Path) -or
            [string]$approval.SHA256 -notmatch '^[A-Fa-f0-9]{64}$' -or
            [string]::IsNullOrWhiteSpace([string]$approval.Reason)) { continue }
        $canonical = Get-CanonicalExecutablePath -Path ([string]$approval.Path)
        $key = $canonical.ToLowerInvariant() + '|' + ([string]$approval.SHA256).ToUpperInvariant()
        $script:ExecutableHashApprovals[$key] = [string]$approval.Reason
    }
}

function Add-HashInventory {
    param(
        [Parameter(Mandatory=$true)][string]$Path,
        [string]$RuleName = '',
        [string]$RuleDisplayName = '',
        [string]$IdentityType = 'Program'
    )
    $canonical = Get-CanonicalExecutablePath -Path $Path
    if (-not (Test-Path -LiteralPath $canonical -PathType Leaf)) { throw ("Executable path no longer exists: {0}" -f $Path) }
    $item = Get-Item -LiteralPath $canonical -ErrorAction Stop
    $hash = (Get-FileHash -LiteralPath $item.FullName -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
    $key = $item.FullName.ToLowerInvariant()
    $baseline = $null
    if ($script:TrustedExecutableHashes.ContainsKey($key)) { $baseline = $script:TrustedExecutableHashes[$key] }
    $approvalKey = $key + '|' + $hash
    $approvalReason = ''
    if ($script:ExecutableHashApprovals.ContainsKey($approvalKey)) { $approvalReason = [string]$script:ExecutableHashApprovals[$approvalKey] }

    $baselineHash = ''
    if ($null -ne $baseline) { $baselineHash = ([string]$baseline.SHA256).ToUpperInvariant() }
    if ($baselineHash -and $baselineHash -eq $hash) {
        $integrityStatus = 'BASELINE_MATCH'
    }
    elseif ($approvalReason) {
        if ($baselineHash) { $integrityStatus = 'APPROVED_HASH_CHANGE' }
        else { $integrityStatus = 'APPROVED_NEW_HASH' }
    }
    elseif ($baselineHash) {
        $integrityStatus = 'HASH_CHANGE_REQUIRES_REVIEW'
    }
    else {
        $integrityStatus = 'NEW_HASH_REQUIRES_APPROVAL'
    }

    $record = [pscustomobject]@{
        Path = $item.FullName
        SHA256 = $hash
        BaselineSHA256 = $baselineHash
        FileSizeBytes = [int64]$item.Length
        LastWriteTimeUtc = $item.LastWriteTimeUtc.ToString('o')
        IntegrityStatus = $integrityStatus
        ApprovalReason = $approvalReason
        RuleName = $RuleName
        RuleDisplayName = $RuleDisplayName
        IdentityType = $IdentityType
    }
    $script:HashInventory.Add($record)
    Write-Status ("SHA-256 {0}: {1}  {2}" -f $integrityStatus,$hash,$item.FullName) $(if ($integrityStatus -match 'REQUIRES_|CHANGE') { 'Yellow' } else { 'DarkGray' })
    return $record
}

function Test-ExecutableHashUnchanged {
    param([AllowNull()][object]$Integrity)
    if ($null -eq $Integrity -or [string]::IsNullOrWhiteSpace([string]$Integrity.Path)) { return $true }
    if (-not (Test-Path -LiteralPath ([string]$Integrity.Path) -PathType Leaf)) {
        throw ("Executable disappeared after discovery: {0}" -f $Integrity.Path)
    }
    $fresh = (Get-FileHash -LiteralPath ([string]$Integrity.Path) -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
    if ($fresh -cne ([string]$Integrity.SHA256).ToUpperInvariant()) {
        throw ("EXECUTABLE_CHANGED_DURING_DEPLOYMENT: {0}; discovered={1}; current={2}" -f $Integrity.Path,$Integrity.SHA256,$fresh)
    }
    return $true
}

function Save-TrustedExecutableBaseline {
    param(
        [Parameter(Mandatory=$true)][object]$Integrity,
        [Parameter(Mandatory=$true)][string]$RuleName
    )
    if ($null -eq $Integrity -or [string]::IsNullOrWhiteSpace([string]$Integrity.Path)) { return }
    $canonical = Get-CanonicalExecutablePath -Path ([string]$Integrity.Path)
    $currentRows = @(Import-Csv -LiteralPath $script:ExecutableBaselinePath -ErrorAction Stop)
    $old = @($currentRows | Where-Object { (Get-CanonicalExecutablePath -Path ([string]$_.Path)).ToLowerInvariant() -eq $canonical.ToLowerInvariant() } | Select-Object -First 1)
    $now = (Get-Date).ToUniversalTime().ToString('o')
    $previousHash = ''
    $firstTrusted = $now
    $lastApprovalReason = [string]$Integrity.ApprovalReason
    if ($old.Length -gt 0) {
        $firstTrusted = [string]$old[0].FirstTrustedUtc
        if ([string]::IsNullOrWhiteSpace($firstTrusted)) { $firstTrusted = $now }
        if (([string]$old[0].SHA256).ToUpperInvariant() -ne ([string]$Integrity.SHA256).ToUpperInvariant()) {
            $previousHash = ([string]$old[0].SHA256).ToUpperInvariant()
        }
        else { $previousHash = [string]$old[0].PreviousSHA256 }
        if ([string]::IsNullOrWhiteSpace($lastApprovalReason)) { $lastApprovalReason = [string]$old[0].LastApprovalReason }
    }
    $row = [pscustomobject]@{
        Path = $canonical
        SHA256 = ([string]$Integrity.SHA256).ToUpperInvariant()
        FileSizeBytes = [int64]$Integrity.FileSizeBytes
        LastWriteTimeUtc = [string]$Integrity.LastWriteTimeUtc
        FirstTrustedUtc = $firstTrusted
        LastVerifiedUtc = $now
        PreviousSHA256 = $previousHash
        LastApprovalReason = $lastApprovalReason
        LastRuleSource = $RuleName
    }
    $newRows = @($currentRows | Where-Object { (Get-CanonicalExecutablePath -Path ([string]$_.Path)).ToLowerInvariant() -ne $canonical.ToLowerInvariant() }) + @($row)
    $tmp = $script:ExecutableBaselinePath + '.tmp'
    $newRows | Sort-Object Path | Export-Csv -LiteralPath $tmp -NoTypeInformation -Encoding UTF8
    Move-Item -LiteralPath $tmp -Destination $script:ExecutableBaselinePath -Force

    # Consume a matching one-time approval after the baseline is durably committed.
    # Historical approval rationale remains in the baseline/audit report; an old approval
    # cannot silently re-trust a later rollback to a previously seen hash.
    if (-not [string]::IsNullOrWhiteSpace([string]$Integrity.ApprovalReason)) {
        $approvalRows = @(Import-Csv -LiteralPath $script:ExecutableApprovalPath -ErrorAction Stop)
        $approvalKey = $canonical.ToLowerInvariant() + '|' + ([string]$Integrity.SHA256).ToUpperInvariant()
        $remainingApprovals = @()
        foreach ($approvalRow in $approvalRows) {
            $drop = $false
            if (-not [string]::IsNullOrWhiteSpace([string]$approvalRow.Path) -and [string]$approvalRow.SHA256 -match '^[A-Fa-f0-9]{64}$') {
                $rowKey = (Get-CanonicalExecutablePath -Path ([string]$approvalRow.Path)).ToLowerInvariant() + '|' + ([string]$approvalRow.SHA256).ToUpperInvariant()
                if ($rowKey -eq $approvalKey) { $drop = $true }
            }
            if (-not $drop) { $remainingApprovals += $approvalRow }
        }
        $approvalTmp = $script:ExecutableApprovalPath + '.tmp'
        if ($remainingApprovals.Count -gt 0) {
            $remainingApprovals | Export-Csv -LiteralPath $approvalTmp -NoTypeInformation -Encoding UTF8
        }
        else {
            'Path,SHA256,Reason' | Set-Content -LiteralPath $approvalTmp -Encoding UTF8
        }
        Move-Item -LiteralPath $approvalTmp -Destination $script:ExecutableApprovalPath -Force
    }
    Initialize-ExecutableTrustStore
    $Integrity.IntegrityStatus = 'BASELINE_ENROLLED_OR_VERIFIED'
    foreach ($auditRow in $script:IntegrityAudit) {
        if ([string]$auditRow.SourceRuleName -ceq $RuleName -and [string]$auditRow.ExecutablePath -ieq $canonical) {
            $auditRow.IntegrityStatus = 'BASELINE_ENROLLED_OR_VERIFIED'
            $auditRow.RuleStatus = 'HASH_BASELINE_SAVED_AFTER_RULE_VERIFICATION'
        }
    }
}

function Get-ServiceHashTarget {
    param([Parameter(Mandatory=$true)][string]$ServiceName)
    $name = $ServiceName.Trim()
    if ([string]::IsNullOrWhiteSpace($name) -or $name -eq 'any') { return $null }

    # For svchost-hosted services, hash the service-specific ServiceDll, not merely
    # the shared svchost.exe host. For standalone services, hash the service image.
    $registryPath = 'HKLM:\SYSTEM\CurrentControlSet\Services\{0}\Parameters' -f $name
    try {
        $parameters = Get-ItemProperty -LiteralPath $registryPath -Name ServiceDll -ErrorAction Stop
        $dllPath = [Environment]::ExpandEnvironmentVariables([string]$parameters.ServiceDll)
        $dllPath = $dllPath -replace '^\\SystemRoot', $env:SystemRoot
        if ($dllPath -match '(?i)^System32\\') { $dllPath = Join-Path $env:SystemRoot $dllPath }
        if (-not [string]::IsNullOrWhiteSpace($dllPath) -and (Test-Path -LiteralPath $dllPath -PathType Leaf)) {
            return [pscustomobject]@{ Path = (Get-Item -LiteralPath $dllPath -ErrorAction Stop).FullName; IdentityType = ('ServiceDll:' + $name) }
        }
    } catch { }

    $serviceRecord = $null
    try {
        $escapedName = $name.Replace("'", "''")
        $serviceRecord = Get-CimInstance -ClassName Win32_Service -Filter ("Name='{0}'" -f $escapedName) -ErrorAction Stop
    } catch {
        try { $serviceRecord = Get-WmiObject -Class Win32_Service -Filter ("Name='{0}'" -f $name.Replace("'", "''")) -ErrorAction Stop } catch { }
    }
    if ($null -eq $serviceRecord) { return $null }
    $binary = [string]$serviceRecord.PathName
    $exePath = ''
    if ($binary -match '^\s*"([^"]+?\.exe)"') { $exePath = $matches[1] }
    elseif ($binary -match '^\s*(.+?\.exe)(?:\s|$)') { $exePath = $matches[1].Trim('"') }
    if ([string]::IsNullOrWhiteSpace($exePath)) { return $null }
    $exePath = [Environment]::ExpandEnvironmentVariables($exePath)
    if ($exePath -match '^\\SystemRoot\\') { $exePath = $exePath -replace '^\\SystemRoot', $env:SystemRoot }
    if (Test-Path -LiteralPath $exePath -PathType Leaf) {
        return [pscustomobject]@{ Path = (Get-Item -LiteralPath $exePath -ErrorAction Stop).FullName; IdentityType = ('ServiceImage:' + $name) }
    }
    return $null
}

function Save-ZTRuleHashManifest {
    param([Parameter(Mandatory=$true)][object]$Candidate)
    $existingRows = @(Import-Csv -LiteralPath $script:RuleHashManifestPath -ErrorAction Stop)
    $kept = @($existingRows | Where-Object { [string]$_.ZTRuleName -cne [string]$Candidate.TargetName })
    $added = @()
    if ($null -ne $Candidate.Integrity -and -not [string]::IsNullOrWhiteSpace([string]$Candidate.Integrity.Path) -and [string]$Candidate.Integrity.SHA256 -match '^[A-Fa-f0-9]{64}$') {
        $added += [pscustomobject]@{
            ZTRuleName = [string]$Candidate.TargetName
            SourceRuleName = [string]$Candidate.SourceRule.Name
            ExecutablePath = [string]$Candidate.Integrity.Path
            IdentityType = [string]$Candidate.Integrity.IdentityType
            SHA256 = ([string]$Candidate.Integrity.SHA256).ToUpperInvariant()
            LastVerifiedUtc = (Get-Date).ToUniversalTime().ToString('o')
        }
    }
    $tmp = $script:RuleHashManifestPath + '.tmp'
    @($kept) + @($added) | Export-Csv -LiteralPath $tmp -NoTypeInformation -Encoding UTF8
    Move-Item -LiteralPath $tmp -Destination $script:RuleHashManifestPath -Force
}

function Get-ApplicationIdentity {

    param([Parameter(Mandatory=$true)][object]$Snapshot)
    $program = @($Snapshot.Program | Where-Object { $_ -ne 'any' })
    $package = @($Snapshot.Package | Where-Object { $_ -ne 'any' })
    $service = @($Snapshot.Service | Where-Object { $_ -ne 'any' })
    $result = New-Object 'System.Collections.Generic.List[string]'
    foreach ($value in $program) { $result.Add(('Program=' + $value)) }
    foreach ($value in $package) { $result.Add(('Package=' + $value)) }
    foreach ($value in $service) { $result.Add(('Service=' + $value)) }
    return $result.ToArray()
}

function Get-ReviewReason {
    param([Parameter(Mandatory=$true)][object]$Rule,[Parameter(Mandatory=$true)][object]$Snapshot)
    if ([string]$Rule.Name -match '(?i)^(ZTWF_|ZT_R_|WSFM_)' -or [string]$Rule.Group -match '(?i)Zero.?Trust|Windows Service Firewall Manager') {
        return 'LEGACY_ZT_OR_WSFM_SOURCE_REQUIRES_BATCH_REVIEW'
    }
    if ($Snapshot.Action -ne 'allow') { return '' }
    if ($Snapshot.OverrideBlockRules -eq 'true') { return 'IPSEC_OVERRIDE_BYPASS_REQUIRES_MANUAL_REVIEW' }

    $programText = (@($Snapshot.Program) -join ';')
    $serviceText = (@($Snapshot.Service) -join ';')
    $protocolText = (@($Snapshot.Protocol) -join ';')
    $remotePorts = @($Snapshot.RemotePort)
    $localPorts = @($Snapshot.LocalPort)
    $remoteAddresses = @($Snapshot.RemoteAddress)
    $direction = $Snapshot.Direction

    if (($programText -match '(?i)(^|[\\/])svchost\.exe($|;)' ) -and $serviceText -eq 'any') {
        return 'SVCHOST_WITHOUT_SERVICE_IDENTITY_REQUIRES_REVIEW'
    }
    if ($serviceText -match '(^|;)dnscache($|;)') {
        if ((($remotePorts -contains '53') -or ($localPorts -contains '53')) -and ($remoteAddresses -contains 'any')) {
            return 'DIRECT_DNS_TO_ANY_DESTINATION_REQUIRES_REVIEW'
        }
    }
    if (($remotePorts -contains '7680') -and ($remoteAddresses -contains 'any') -and ($serviceText -match '(^|;)dosvc($|;)')) {
        return 'DELIVERY_OPTIMIZATION_PEER_TO_ANY_REQUIRES_REVIEW'
    }
    if (($remotePorts -contains '5353') -or ($remotePorts -contains '5355') -or
        ($localPorts -contains '5353') -or ($localPorts -contains '5355')) {
        return 'LOCAL_MULTICAST_OR_NAME_DISCOVERY_REQUIRES_REVIEW'
    }
    if ($protocolText -contains 'any') {
        return 'ALLOW_ANY_PROTOCOL_REQUIRES_REVIEW'
    }
    if (($protocolText -contains 'tcp') -or ($protocolText -contains 'udp')) {
        if ($direction -eq 'outbound' -and $remotePorts -contains 'any') {
            return 'OUTBOUND_ALLOW_WITH_ANY_REMOTE_PORT_REQUIRES_REVIEW'
        }
        if ($direction -eq 'inbound' -and $localPorts -contains 'any') {
            return 'INBOUND_ALLOW_WITH_ANY_LOCAL_PORT_REQUIRES_REVIEW'
        }
    }
    if ($direction -eq 'inbound' -and $remoteAddresses -contains 'any') {
        return 'INBOUND_ALLOW_FROM_ANY_REMOTE_ADDRESS_REQUIRES_REVIEW'
    }
    return ''
}

function Get-SourceApprovalReason {
    param([Parameter(Mandatory=$true)][string]$RuleName,[Parameter(Mandatory=$true)][string]$Fingerprint)
    $match = @($script:SourceApprovals | Where-Object {
        [string]$_.Name -ceq $RuleName -and
        [string]$_.Fingerprint -ceq $Fingerprint -and
        -not [string]::IsNullOrWhiteSpace([string]$_.Reason)
    } | Select-Object -First 1)
    if ($match.Length -gt 0) { return [string]$match[0].Reason }
    return ''
}

function Get-TargetRuleName {
    param([Parameter(Mandatory=$true)][string]$SourceName)
    return ($script:RulePrefix + (Get-ShortTextHash -Text $SourceName -Length 24))
}

function Get-CloneDisplayName {
    param([Parameter(Mandatory=$true)][object]$Rule)
    $original = [string]$Rule.DisplayName
    if ([string]::IsNullOrWhiteSpace($original)) { $original = [string]$Rule.Name }
    $display = 'ZT- ' + $original
    if ($display.Length -gt 220) { $display = $display.Substring(0,220) }
    return $display
}

function New-CloneParameters {
    param([Parameter(Mandatory=$true)][object]$Rule,[Parameter(Mandatory=$true)][object]$Snapshot,[Parameter(Mandatory=$true)][string]$TargetName,[AllowNull()][object]$Integrity)
    $sourceName = [string]$Rule.Name
    $fingerprint = Get-SnapshotFingerprint -Snapshot $Snapshot
    $hashText = 'SHA256=NOT-RESOLVED'
    if ($null -ne $Integrity -and [string]$Integrity.SHA256 -match '^[A-Fa-f0-9]{64}$') { $hashText = ('SHA256=' + ([string]$Integrity.SHA256).ToUpperInvariant()) }
    $description = ('{0}; ZT source={1}; audit-only; fp={2}' -f $hashText,$sourceName,$fingerprint)
    if ($description.Length -gt 255) { $description = $description.Substring(0,255) }

    $enabledText = if ($Snapshot.Enabled -eq 'true') { 'True' } else { 'False' }
    $directionText = if ($Snapshot.Direction -eq 'inbound') { 'Inbound' } else { 'Outbound' }
    $actionText = if ($Snapshot.Action -eq 'block') { 'Block' } else { 'Allow' }
    $params = @{
        Name = $TargetName
        DisplayName = (Get-CloneDisplayName -Rule $Rule)
        Description = $description
        Group = $script:ManagedGroup
        Enabled = $enabledText
        Profile = [string[]]@($Snapshot.Profile)
        Direction = $directionText
        Action = $actionText
        PolicyStore = 'PersistentStore'
        ErrorAction = 'Stop'
    }

    foreach ($field in @('Program','Package','Service')) {
        $values = @($Snapshot.$field | Where-Object { $_ -ne 'any' })
        if ($values.Length -gt 1) { throw ("Source rule '{0}' has multiple {1} identities; refusing to merge them." -f $sourceName,$field) }
        if ($values.Length -eq 1) { $params[$field] = [string]$values[0] }
    }

    $protocol = @($Snapshot.Protocol | Where-Object { $_ -ne 'any' })
    if ($protocol.Length -gt 1) { throw ("Source rule '{0}' has multiple protocols; refusing to merge them." -f $sourceName) }
    if ($protocol.Length -eq 1) { $params.Protocol = [string]$protocol[0] }

    foreach ($field in @('Platform','LocalPort','RemotePort','IcmpType','LocalAddress','RemoteAddress','RemoteDynamicKeywordAddresses','InterfaceAlias')) {
        $values = @($Snapshot.$field | Where-Object { $_ -ne 'any' })
        if ($values.Length -gt 0) { $params[$field] = [string[]]$values }
    }

    $dynamicTarget = @($Snapshot.DynamicTarget | Where-Object { $_ -ne 'any' })
    if ($dynamicTarget.Length -gt 1) { throw ("Source rule '{0}' has multiple dynamic targets." -f $sourceName) }
    if ($dynamicTarget.Length -eq 1) { $params.DynamicTarget = [string]$dynamicTarget[0] }

    $interfaceType = @($Snapshot.InterfaceType | Where-Object { $_ -ne 'any' })
    if ($interfaceType.Length -gt 1) { throw ("Source rule '{0}' has multiple interface types." -f $sourceName) }
    if ($interfaceType.Length -eq 1) { $params.InterfaceType = [string]$interfaceType[0] }

    if ($Snapshot.Direction -eq 'inbound') {
        $params.EdgeTraversalPolicy = switch ($Snapshot.EdgeTraversalPolicy) {
            'allow' { 'Allow' }
            'defertouser' { 'DeferToUser' }
            'defer to user' { 'DeferToUser' }
            'defertoapp' { 'DeferToApp' }
            'defer to app' { 'DeferToApp' }
            default { 'Block' }
        }
    }
    $params.LooseSourceMapping = ($Snapshot.LooseSourceMapping -eq 'true')
    $params.LocalOnlyMapping = ($Snapshot.LocalOnlyMapping -eq 'true')
    $ownerValues = @($Snapshot.Owner | Where-Object { $_ -ne 'any' })
    if ($ownerValues.Length -eq 1) { $params.Owner = [string]$ownerValues[0] }

    $params.Authentication = switch ($Snapshot.Authentication) {
        'required' { 'Required' }
        'noencap' { 'NoEncap' }
        default { 'NotRequired' }
    }
    $params.Encryption = switch ($Snapshot.Encryption) {
        'required' { 'Required' }
        'dynamic' { 'Dynamic' }
        default { 'NotRequired' }
    }
    $params.OverrideBlockRules = ($Snapshot.OverrideBlockRules -eq 'true')
    foreach ($field in @('LocalUser','RemoteUser','RemoteMachine')) {
        $values = @($Snapshot.$field | Where-Object { $_ -ne 'any' })
        if ($values.Length -gt 1) { throw ("Source rule '{0}' has multiple {1} security identities; refusing to merge them." -f $sourceName,$field) }
        if ($values.Length -eq 1) { $params[$field] = [string]$values[0] }
    }
    return $params
}

function Test-ExistingClone {
    param([Parameter(Mandatory=$true)][object]$ExistingRule,[Parameter(Mandatory=$true)][object]$SourceSnapshot,[Parameter(Mandatory=$true)][string]$ExpectedDisplayName)
    try {
        if ([string]$ExistingRule.Group -ne $script:ManagedGroup) { return $false }
        if ([string]$ExistingRule.DisplayName -ne $ExpectedDisplayName) { return $false }
        $existingSnapshot = Get-RuleSnapshot -Rule $ExistingRule
        $sourceHash = Get-SnapshotFingerprint -Snapshot $SourceSnapshot
        $existingHash = Get-SnapshotFingerprint -Snapshot $existingSnapshot
        return ($sourceHash -eq $existingHash)
    }
    catch { return $false }
}

function Get-SourceRuleCandidates {
    Import-Module NetSecurity -ErrorAction Stop
    $script:SourceApprovals = @(Import-Csv -LiteralPath $script:SourceApprovalPath -ErrorAction Stop)
    $rules = @(Get-NetFirewallRule -PolicyStore PersistentStore -ErrorAction Stop)
    $candidates = New-Object 'System.Collections.Generic.List[object]'
    foreach ($rule in $rules) {
        if (([string]$rule.Name).StartsWith($script:RulePrefix,[StringComparison]::OrdinalIgnoreCase) -and [string]$rule.Group -eq $script:ManagedGroup) { continue }
        try {
            $snapshot = Get-RuleSnapshot -Rule $rule
            $identity = @(Get-ApplicationIdentity -Snapshot $snapshot)
            if ($identity.Length -eq 0) { continue }
            $script:Stats.Discovered++

            foreach ($identityField in @('Program','Package','Service')) {
                $identityValues = @($snapshot.$identityField | Where-Object { $_ -ne 'any' })
                if ($identityValues.Length -gt 1) { throw ("Multiple {0} identities are not supported." -f $identityField) }
            }
            $programIdentity = @($snapshot.Program | Where-Object { $_ -ne 'any' })
            $packageIdentity = @($snapshot.Package | Where-Object { $_ -ne 'any' })
            $serviceIdentity = @($snapshot.Service | Where-Object { $_ -ne 'any' })
            $protocolValues = @($snapshot.Protocol | Where-Object { $_ -ne 'any' })
            if ($protocolValues.Length -gt 1) { throw 'Multiple protocols in one source rule are not supported.' }
            $dynamicValues = @($snapshot.DynamicTarget | Where-Object { $_ -ne 'any' })
            if ($dynamicValues.Length -gt 1) { throw 'Multiple dynamic targets in one source rule are not supported.' }
            $interfaceTypeValues = @($snapshot.InterfaceType | Where-Object { $_ -ne 'any' })
            if ($interfaceTypeValues.Length -gt 1) { throw 'Multiple interface types in one source rule are not supported.' }

            $integrityCheck = [pscustomobject]@{
                Path = ''; SHA256 = ''; BaselineSHA256 = ''; FileSizeBytes = 0L
                LastWriteTimeUtc = ''; IntegrityStatus = 'NO_FILE_BACKED_PROGRAM_IDENTITY'
                ApprovalReason = ''; RuleName = [string]$rule.Name; RuleDisplayName = [string]$rule.DisplayName
                IdentityType = 'Unresolved'
            }
            $program = ''
            if ($programIdentity.Length -eq 1) { $program = [string]$programIdentity[0] }
            $selectedPath = ''
            $identityType = ''

            # Direct executable identities are preferred. A service-specific DLL is
            # preferred over shared svchost.exe when the rule contains a service filter.
            if ($program -and $program -ne 'system') {
                $expanded = [Environment]::ExpandEnvironmentVariables($program.Trim().Trim('"'))
                if ($expanded -match '(?i)^\\SystemRoot\\') { $expanded = $expanded -replace '(?i)^\\SystemRoot', $env:SystemRoot }
                if ($expanded -match '^[A-Za-z]:[\\/]' -or $expanded -match '^\\\\') {
                    if ($serviceIdentity.Length -eq 1 -and [IO.Path]::GetFileName($expanded) -ieq 'svchost.exe') {
                        $serviceTarget = Get-ServiceHashTarget -ServiceName ([string]$serviceIdentity[0])
                        if ($null -ne $serviceTarget) { $selectedPath = [string]$serviceTarget.Path; $identityType = [string]$serviceTarget.IdentityType }
                    }
                    if (-not $selectedPath) { $selectedPath = $expanded; $identityType = 'Program' }
                }
                else {
                    $integrityCheck.Path = $program
                    $integrityCheck.IntegrityStatus = 'UNRESOLVED_EXECUTABLE_PATH_REQUIRES_REVIEW'
                }
            }
            elseif ($serviceIdentity.Length -eq 1) {
                $serviceTarget = Get-ServiceHashTarget -ServiceName ([string]$serviceIdentity[0])
                if ($null -ne $serviceTarget) { $selectedPath = [string]$serviceTarget.Path; $identityType = [string]$serviceTarget.IdentityType }
                else {
                    $integrityCheck.IntegrityStatus = 'SERVICE_BINARY_PATH_NOT_RESOLVED_REQUIRES_REVIEW'
                    $integrityCheck.IdentityType = 'Service:' + [string]$serviceIdentity[0]
                }
            }
            elseif ($program -eq 'system' -and $serviceIdentity.Length -eq 1) {
                # A system-scoped service rule still has a service-specific binary:
                # hash ServiceDll or the service image rather than the generic System identity.
                $serviceTarget = Get-ServiceHashTarget -ServiceName ([string]$serviceIdentity[0])
                if ($null -ne $serviceTarget) {
                    $selectedPath = [string]$serviceTarget.Path
                    $identityType = [string]$serviceTarget.IdentityType
                }
                else {
                    $integrityCheck.IntegrityStatus = 'SERVICE_BINARY_PATH_NOT_RESOLVED_REQUIRES_REVIEW'
                    $integrityCheck.IdentityType = 'Service:' + [string]$serviceIdentity[0]
                }
            }
            elseif ($program -eq 'system') {
                $integrityCheck.IntegrityStatus = 'SYSTEM_IDENTITY_NO_FILE_HASH'
            }

            if ($selectedPath) {
                $integrityCheck = Add-HashInventory -Path $selectedPath -RuleName ([string]$rule.Name) -RuleDisplayName ([string]$rule.DisplayName) -IdentityType $identityType
            }

            if ($packageIdentity.Length -gt 0 -and -not $selectedPath) {
                $integrityCheck.IntegrityStatus = 'PACKAGE_EXECUTABLE_PATH_NOT_RESOLVED_REQUIRES_REVIEW'
                $integrityCheck.IdentityType = 'Package:' + [string]$packageIdentity[0]
            }

            if ($snapshot.OverrideBlockRules -eq 'true' -and $snapshot.Authentication -eq 'notrequired') {
                throw 'Source rule combines OverrideBlockRules=True with Authentication=NotRequired; Windows Firewall does not accept this combination for a new rule, so it cannot be cloned exactly.'
            }

            $reason = Get-ReviewReason -Rule $rule -Snapshot $snapshot
            if ($programIdentity.Length -gt 0 -and $packageIdentity.Length -gt 0) { $reason = 'PROGRAM_AND_PACKAGE_IDENTITY_COMBINATION_REQUIRES_REVIEW' }
            $integrityNeedsApproval = ([string]$integrityCheck.IntegrityStatus -in @('HASH_CHANGE_REQUIRES_REVIEW','UNRESOLVED_EXECUTABLE_PATH_REQUIRES_REVIEW','SERVICE_BINARY_PATH_NOT_RESOLVED_REQUIRES_REVIEW','PACKAGE_EXECUTABLE_PATH_NOT_RESOLVED_REQUIRES_REVIEW','SYSTEM_IDENTITY_NO_FILE_HASH'))
            if ($integrityNeedsApproval) {
                if ($reason) { $reason += '; ' + [string]$integrityCheck.IntegrityStatus }
                else { $reason = [string]$integrityCheck.IntegrityStatus }
            }
            $targetName = Get-TargetRuleName -SourceName ([string]$rule.Name)
            $targetDisplayName = Get-CloneDisplayName -Rule $rule
            $sourceFingerprint = Get-SnapshotFingerprint -Snapshot $snapshot
            $newHashPending = ([string]$integrityCheck.IntegrityStatus -eq 'NEW_HASH_REQUIRES_APPROVAL')
            $status = 'ELIGIBLE'
            if ($integrityNeedsApproval) {
                $status = 'REVIEW_REQUIRED'
            }
            elseif ($reason) {
                $approvalReason = Get-SourceApprovalReason -RuleName ([string]$rule.Name) -Fingerprint $sourceFingerprint
                if ($approvalReason) {
                    $status = 'APPROVED_BY_OPERATOR'
                    $reason = ('MANUALLY_APPROVED: {0} | Original hold: {1}' -f $approvalReason,$reason)
                }
                else { $status = 'REVIEW_REQUIRED' }
            }
            elseif ($newHashPending) { $status = 'ELIGIBLE_NEW_HASH_PENDING' }

            $candidate = [pscustomobject]@{
                SourceRule = $rule
                Snapshot = $snapshot
                Identity = ($identity -join '; ')
                Integrity = $integrityCheck
                SourceFingerprint = $sourceFingerprint
                TargetName = $targetName
                TargetDisplayName = $targetDisplayName
                ReviewReason = $reason
                Status = $status
                SourceDisabledByMigration = $false
                Message = ''
            }
            $candidates.Add($candidate)
            $script:IntegrityAudit.Add([pscustomobject]@{
                ScanUtc = (Get-Date).ToUniversalTime().ToString('o')
                SourceRuleName = [string]$rule.Name
                SourceDisplayName = [string]$rule.DisplayName
                TargetZTName = $targetName
                ApplicationIdentity = ($identity -join '; ')
                ExecutablePath = [string]$integrityCheck.Path
                BaselineSHA256 = [string]$integrityCheck.BaselineSHA256
                CurrentSHA256 = [string]$integrityCheck.SHA256
                FileSizeBytes = [string]$integrityCheck.FileSizeBytes
                LastWriteTimeUtc = [string]$integrityCheck.LastWriteTimeUtc
                IntegrityStatus = [string]$integrityCheck.IntegrityStatus
                ApprovalReason = [string]$integrityCheck.ApprovalReason
                RuleStatus = $status
                ReviewReason = $reason
            })
        }
        catch {
            $script:Stats.Errors++
            $candidates.Add([pscustomobject]@{
                SourceRule = $rule; Snapshot = $null; Identity = ''; Integrity = $null
                SourceFingerprint = ''; TargetName = ''; TargetDisplayName = ''
                ReviewReason = 'DISCOVERY_ERROR_OR_STALE_IDENTITY'; Status = 'SKIPPED'
                SourceDisabledByMigration = $false; Message = $_.Exception.Message
            })
            $script:IntegrityAudit.Add([pscustomobject]@{
                ScanUtc = (Get-Date).ToUniversalTime().ToString('o')
                SourceRuleName = [string]$rule.Name; SourceDisplayName = [string]$rule.DisplayName
                TargetZTName = ''; ApplicationIdentity = ''; ExecutablePath = ''
                BaselineSHA256 = ''; CurrentSHA256 = ''; FileSizeBytes = ''; LastWriteTimeUtc = ''
                IntegrityStatus = 'DISCOVERY_ERROR'; ApprovalReason = ''; RuleStatus = 'SKIPPED'
                ReviewReason = $_.Exception.Message
            })
        }
    }
    return $candidates.ToArray()
}

function Export-ConversionReports {
    param([object[]]$Candidates)
    $rows = foreach ($candidate in $Candidates) {
        $rule = $candidate.SourceRule
        [pscustomobject]@{
            SourceName = [string]$rule.Name
            SourceDisplayName = [string]$rule.DisplayName
            SourceGroup = [string]$rule.Group
            EnabledAtScan = [string]$rule.Enabled
            SourceDisabledByMigration = [bool]$candidate.SourceDisabledByMigration
            Direction = [string]$rule.Direction
            Action = [string]$rule.Action
            ApplicationIdentity = [string]$candidate.Identity
            TargetZTName = [string]$candidate.TargetName
            Status = [string]$candidate.Status
            ReviewReason = [string]$candidate.ReviewReason
            SourceFingerprint = [string]$candidate.SourceFingerprint
            ExecutablePath = [string]$(if ($null -ne $candidate.Integrity) { $candidate.Integrity.Path } else { '' })
            ExecutableSHA256 = [string]$(if ($null -ne $candidate.Integrity) { $candidate.Integrity.SHA256 } else { '' })
            IntegrityStatus = [string]$(if ($null -ne $candidate.Integrity) { $candidate.Integrity.IntegrityStatus } else { 'DISCOVERY_ERROR' })
            Details = [string]$candidate.Message
        }
    }
    if ($null -ne $rows -and @($rows).Length -gt 0) {
        $rows | Export-Csv -LiteralPath $script:ResultsPath -NoTypeInformation -Encoding UTF8
    }
    else {
        'SourceName,SourceDisplayName,SourceGroup,EnabledAtScan,SourceDisabledByMigration,Direction,Action,ApplicationIdentity,TargetZTName,Status,ReviewReason,SourceFingerprint,ExecutablePath,ExecutableSHA256,IntegrityStatus,Details' | Set-Content -LiteralPath $script:ResultsPath -Encoding UTF8
    }
    if ($script:HashInventory.Count -gt 0) {
        $script:HashInventory | Export-Csv -LiteralPath $script:InventoryPath -NoTypeInformation -Encoding UTF8
    }
    else {
        'Path,SHA256,BaselineSHA256,FileSizeBytes,LastWriteTimeUtc,IntegrityStatus,ApprovalReason,RuleName,RuleDisplayName,IdentityType' | Set-Content -LiteralPath $script:InventoryPath -Encoding UTF8
    }
    if ($script:IntegrityAudit.Count -gt 0) {
        $script:IntegrityAudit | Export-Csv -LiteralPath $script:IntegrityAuditPath -NoTypeInformation -Encoding UTF8
    }
    else {
        'ScanUtc,SourceRuleName,SourceDisplayName,TargetZTName,ApplicationIdentity,ExecutablePath,BaselineSHA256,CurrentSHA256,FileSizeBytes,LastWriteTimeUtc,IntegrityStatus,ApprovalReason,RuleStatus,ReviewReason' | Set-Content -LiteralPath $script:IntegrityAuditPath -Encoding UTF8
    }
    Write-Status ("Conversion inventory: {0}" -f $script:ResultsPath) 'Cyan'
    Write-Status ("Executable SHA-256 inventory: {0}" -f $script:InventoryPath) 'Cyan'
    Write-Status ("Complete executable integrity audit: {0}" -f $script:IntegrityAuditPath) 'Cyan'
    Write-Status ("Persistent trust baseline: {0}" -f $script:ExecutableBaselinePath) 'Cyan'
}

function Invoke-Preview {
    $script:Stats = [ordered]@{ Discovered=0; Eligible=0; Created=0; Updated=0; Unchanged=0; RetiredSources=0; Review=0; Skipped=0; Errors=0; Removed=0 }
    $script:HashInventory = New-Object 'System.Collections.Generic.List[object]'
    $script:HashSeen = @{}
    $script:IntegrityAudit = New-Object 'System.Collections.Generic.List[object]'
    Initialize-ExecutableTrustStore
    Write-Status "`nScanning local persistent firewall rules for existing app/service identities and executable integrity..." 'Cyan'
    $candidates = @(Get-SourceRuleCandidates)
    $eligible = @($candidates | Where-Object { $_.Status -in @('ELIGIBLE','APPROVED_BY_OPERATOR','ELIGIBLE_NEW_HASH_PENDING') })
    $review = @($candidates | Where-Object { $_.Status -eq 'REVIEW_REQUIRED' })
    $skipped = @($candidates | Where-Object { $_.Status -eq 'SKIPPED' })
    $script:Stats.Eligible = $eligible.Length
    $script:Stats.Review = $review.Length
    $script:Stats.Skipped = $skipped.Length
    Export-ConversionReports -Candidates $candidates

    Write-Status "`nDiscovery summary" 'Cyan'
    Write-Status ("Application/service rules discovered : {0}" -f $script:Stats.Discovered) 'White'
    Write-Status ("Eligible / pending explicit hash enrollment: {0}" -f $eligible.Length) 'Green'
    Write-Status ("Held for manual review              : {0}" -f $review.Length) 'Yellow'
    Write-Status ("Skipped due to stale/unsupported data: {0}" -f $skipped.Length) 'DarkGray'
    if ($eligible.Length -gt 0) {
        Write-Status "`nEligible source rules (originals remain untouched):" 'Green'
        foreach ($candidate in ($eligible | Select-Object -First 25)) {
            Write-Host ("  {0}  ->  {1}" -f $candidate.SourceRule.DisplayName,$candidate.TargetName)
        }
        if ($eligible.Length -gt 25) { Write-Host ("  ... plus {0} more; see the CSV report." -f ($eligible.Length - 25)) }
    }
    if ($review.Length -gt 0) {
        Write-Status "`nExamples held for review:" 'Yellow'
        foreach ($candidate in ($review | Select-Object -First 15)) {
            Write-Host ("  {0}  [{1}]" -f $candidate.SourceRule.DisplayName,$candidate.ReviewReason)
        }
        if ($review.Length -gt 15) { Write-Host ("  ... plus {0} more; see the CSV report." -f ($review.Length - 15)) }
    }
    Write-Status "`nNo firewall rules were changed by Preview." 'Green'
    return $candidates
}

function Export-FirewallBackup {
    param([string]$Destination)
    if ([string]::IsNullOrWhiteSpace($Destination)) {
        $stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
        $Destination = Join-Path $script:BackupDir ("WindowsFirewall_{0}.wfw" -f $stamp)
    }
    $netsh = Join-Path $env:SystemRoot 'System32\netsh.exe'
    & $netsh advfirewall export $Destination | Out-Null
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $Destination -PathType Leaf)) {
        throw 'Windows Firewall policy export failed.'
    }
    $backupItem = Get-Item -LiteralPath $Destination -ErrorAction Stop
    if ($backupItem.Length -lt 128) { throw 'Firewall backup is unexpectedly small; refusing to treat it as verified.' }
    $backupHash = (Get-FileHash -LiteralPath $Destination -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
    $hashPath = $Destination + '.sha256.txt'
    ('{0}  {1}' -f $backupHash,[IO.Path]::GetFileName($Destination)) | Set-Content -LiteralPath $hashPath -Encoding ASCII
    Write-Status ("Full firewall backup saved: {0}" -f $Destination) 'Green'
    Write-Status ("Backup SHA-256: {0}" -f $backupHash) 'Cyan'
    return $Destination
}

function Disable-SourceRuleAfterClone {
    param([Parameter(Mandatory=$true)][object]$SourceRule)
    if (-not $script:RetireSourceRules -or [string]$SourceRule.Enabled -ne 'True') { return $false }
    Set-NetFirewallRule -InputObject $SourceRule -Enabled False -ErrorAction Stop
    $verifiedSource = @(Get-NetFirewallRule -PolicyStore PersistentStore -Name ([string]$SourceRule.Name) -ErrorAction Stop)
    if ($verifiedSource.Length -ne 1 -or [string]$verifiedSource[0].Enabled -ne 'False') {
        throw ("ZT copy is verified, but original source rule '{0}' could not be confirmed disabled. Both rules may remain enabled; inspect the report." -f $SourceRule.Name)
    }
    return $true
}

function Get-ZTTargetRuleState {
    param([Parameter(Mandatory=$true)][string]$TargetName)
    try {
        $found = @(Get-NetFirewallRule -PolicyStore PersistentStore -Name $TargetName -ErrorAction SilentlyContinue |
            Where-Object { [string]$_.Name -ceq $TargetName })
        if ($found.Length -eq 0) { return 'NEW' }
        $foreign = @($found | Where-Object { [string]$_.Group -cne $script:ManagedGroup })
        if ($foreign.Length -gt 0) { return 'NAME_COLLISION' }
        return 'EXISTING_MANAGED'
    }
    catch { return 'UNKNOWN' }
}

function Invoke-BatchSourceApproval {
    param([Parameter(Mandatory=$true)][object[]]$Candidates)

    # Source-rule approval is a separate gate from executable hash trust.
    # A batch source approval must never bypass a changed or unresolvable file hash.
    $reviewCandidates = @($Candidates | Where-Object { [string]$_.Status -eq 'REVIEW_REQUIRED' } |
        Sort-Object { [string]$_.SourceRule.Name })
    if ($reviewCandidates.Length -eq 0) {
        Write-Status 'No source rules require batch approval.' 'Green'
        return 0
    }

    $hardHashHold = 'NEW_HASH_REQUIRES_APPROVAL|HASH_CHANGE_REQUIRES_REVIEW|UNRESOLVED_EXECUTABLE_PATH|SERVICE_BINARY_PATH_NOT_RESOLVED|PACKAGE_EXECUTABLE_PATH_NOT_RESOLVED|SYSTEM_IDENTITY_NO_FILE_HASH|DISCOVERY_ERROR'
    $evaluation = New-Object 'System.Collections.Generic.List[object]'
    foreach ($candidate in $reviewCandidates) {
        $integrityStatus = ''
        if ($null -ne $candidate.Integrity) { $integrityStatus = [string]$candidate.Integrity.IntegrityStatus }
        $reason = [string]$candidate.ReviewReason
        $nonHashable = ($integrityStatus -match $hardHashHold) -or ($reason -match $hardHashHold)
        $targetState = 'UNKNOWN'
        if (-not [string]::IsNullOrWhiteSpace([string]$candidate.TargetName)) {
            $targetState = Get-ZTTargetRuleState -TargetName ([string]$candidate.TargetName)
        }
        $evaluation.Add([pscustomobject]@{
            Candidate = $candidate
            TargetState = $targetState
            HashHold = $nonHashable
        })
    }

    $batchable = @($evaluation | Where-Object { -not $_.HashHold -and $_.TargetState -in @('NEW','EXISTING_MANAGED') })
    $newOnly = @($batchable | Where-Object { $_.TargetState -eq 'NEW' })
    $hashHeld = @($evaluation | Where-Object { $_.HashHold })
    $collisions = @($evaluation | Where-Object { $_.TargetState -eq 'NAME_COLLISION' -or $_.TargetState -eq 'UNKNOWN' })

    Write-Status "`nBatch source-rule approval" 'Cyan'
    Write-Status ("Review candidates: {0} | Batch-approvable: {1} | New ZT rules: {2} | Hash/path holds: {3} | Name collisions/unknown: {4}" -f $reviewCandidates.Length,$batchable.Length,$newOnly.Length,$hashHeld.Length,$collisions.Length) 'White'
    Write-Host '[1] APPROVE ALL RULE' -ForegroundColor Yellow
    Write-Host '    Batch-approve all reviewable source rules, in alphabetical rule-name order.'
    Write-Host '[2] APPROVE ONLY NEW RULE' -ForegroundColor Yellow
    Write-Host '    Batch-approve only rules whose ZT- counterpart does not exist yet.'
    Write-Host '[0] SKIP APPROVAL' -ForegroundColor DarkGray
    Write-Host '    Keep all source-rule review candidates on hold.'
    Write-Host ''
    $selection = Read-Host 'Select approval mode [1/2/0]'

    $selected = @()
    $approvalMode = ''
    switch ($selection) {
        '1' {
            $selected = @($batchable)
            $approvalMode = 'APPROVE ALL RULE'
        }
        '2' {
            $selected = @($newOnly)
            $approvalMode = 'APPROVE ONLY NEW RULE'
        }
        '0' {
            Write-Status 'Batch approval skipped; all review candidates remain held.' 'Yellow'
            return 0
        }
        default {
            Write-Status 'Invalid approval selection; no source rules were approved.' 'Yellow'
            return 0
        }
    }

    if ($selected.Length -eq 0) {
        Write-Status 'No rules matched the selected approval mode. No source approvals were written.' 'Yellow'
        return 0
    }

    $approved = 0
    $sequence = 0
    $total = $selected.Length
    $timestamp = (Get-Date).ToUniversalTime().ToString('o')
    foreach ($entry in $selected) {
        $sequence++
        $candidate = $entry.Candidate
        $originalReason = [string]$candidate.ReviewReason
        $reason = ('Batch approved in v2.0.6: {0}; sequence {1}/{2}; UTC {3}; original review: {4}' -f $approvalMode,$sequence,$total,$timestamp,$originalReason)
        $record = [pscustomobject]@{
            Name = [string]$candidate.SourceRule.Name
            Fingerprint = [string]$candidate.SourceFingerprint
            Reason = $reason
        }
        # Replace only a prior row for the exact same name + current fingerprint.
        $script:SourceApprovals = @($script:SourceApprovals | Where-Object {
            -not ([string]$_.Name -ceq [string]$record.Name -and [string]$_.Fingerprint -ceq [string]$record.Fingerprint)
        }) + @($record)

        $candidate.Status = 'APPROVED_BY_OPERATOR'
        $candidate.ReviewReason = ('BATCH_APPROVED ({0}): {1}' -f $approvalMode,$originalReason)
        foreach ($auditRow in $script:IntegrityAudit) {
            if ([string]$auditRow.SourceRuleName -ceq [string]$candidate.SourceRule.Name) {
                $auditRow.ApprovalReason = $reason
                $auditRow.RuleStatus = 'APPROVED_BY_OPERATOR'
                $auditRow.ReviewReason = [string]$candidate.ReviewReason
            }
        }
        Write-Status ("[{0}/{1}] APPROVED: {2}" -f $sequence,$total,$candidate.SourceRule.DisplayName) 'Green'
        $approved++
    }

    $approvalTmp = $script:SourceApprovalPath + '.tmp'
    $script:SourceApprovals | Export-Csv -LiteralPath $approvalTmp -NoTypeInformation -Encoding UTF8
    Move-Item -LiteralPath $approvalTmp -Destination $script:SourceApprovalPath -Force
    Write-Status ("Batch approval complete: {0} rule(s) approved using {1}. Hash/path holds and target-name conflicts were not approved." -f $approved,$approvalMode) 'Green'
    return $approved
}

function ConvertTo-MigrationPlanCandidate {
    param([Parameter(Mandatory=$true)][object]$Candidate)
    $rule = $Candidate.SourceRule
    $deletedUtc = ''
    $createdUtc = ''
    if ($null -ne $Candidate.PSObject.Properties['DeletedUtc']) { $deletedUtc = [string]$Candidate.DeletedUtc }
    if ($null -ne $Candidate.PSObject.Properties['CreatedUtc']) { $createdUtc = [string]$Candidate.CreatedUtc }
    return [pscustomobject]@{
        SourceRule = [pscustomobject]@{
            Name = [string]$rule.Name
            DisplayName = [string]$rule.DisplayName
            Group = [string]$rule.Group
            Enabled = [string]$rule.Enabled
            Direction = [string]$rule.Direction
            Action = [string]$rule.Action
        }
        Snapshot = $Candidate.Snapshot
        Identity = [string]$Candidate.Identity
        Integrity = $Candidate.Integrity
        SourceFingerprint = [string]$Candidate.SourceFingerprint
        TargetName = [string]$Candidate.TargetName
        TargetDisplayName = [string]$Candidate.TargetDisplayName
        ReviewReason = [string]$Candidate.ReviewReason
        Status = [string]$Candidate.Status
        Message = [string]$Candidate.Message
        DeletedUtc = $deletedUtc
        CreatedUtc = $createdUtc
    }
}

function Save-MigrationPlan {
    param([Parameter(Mandatory=$true)][object]$Plan)
    # Store backup paths relative to the package root so the folder can be moved as
    # one unit without invalidating the staged plan or its .wfw restore point.
    $backupPath = [string]$Plan.PolicyBackupPath
    if (-not [string]::IsNullOrWhiteSpace($backupPath) -and [IO.Path]::IsPathRooted($backupPath)) {
        $rootFull = [IO.Path]::GetFullPath($script:Root).TrimEnd('\')
        $backupFull = [IO.Path]::GetFullPath($backupPath)
        if ($backupFull.StartsWith($rootFull + '\',[StringComparison]::OrdinalIgnoreCase)) {
            $Plan.PolicyBackupPath = $backupFull.Substring($rootFull.Length).TrimStart('\')
        }
    }
    $json = $Plan | ConvertTo-Json -Depth 30
    $tmp = [string]$Plan.PlanPath + '.tmp'
    Set-Content -LiteralPath $tmp -Value $json -Encoding UTF8
    Move-Item -LiteralPath $tmp -Destination ([string]$Plan.PlanPath) -Force
    Set-Content -LiteralPath $script:MigrationPlanPointerPath -Value (Split-Path -Leaf ([string]$Plan.PlanPath)) -Encoding UTF8
}

function Read-MigrationPlan {
    if (-not (Test-Path -LiteralPath $script:MigrationPlanPointerPath -PathType Leaf)) {
        throw 'No staged migration plan exists. Run menu option 1 (BACK UP EXISTING RULES) first.'
    }
    $path = (Get-Content -LiteralPath $script:MigrationPlanPointerPath -ErrorAction Stop | Select-Object -First 1).Trim()
    if (-not [IO.Path]::IsPathRooted($path)) { $path = Join-Path $script:BackupDir $path }
    if ([string]::IsNullOrWhiteSpace($path) -or -not (Test-Path -LiteralPath $path -PathType Leaf)) {
        throw 'The current migration plan pointer is invalid or its plan file is missing. Run option 1 again.'
    }
    $plan = Get-Content -LiteralPath $path -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
    if ([int]$plan.SchemaVersion -ne 1) { throw 'Unsupported migration-plan schema. Create a fresh backup using option 1.' }
    $backupPath = [string]$plan.PolicyBackupPath
    if (-not [IO.Path]::IsPathRooted($backupPath)) { $backupPath = Join-Path $script:Root $backupPath }
    $plan.PolicyBackupPath = $backupPath
    if (-not (Test-Path -LiteralPath $backupPath -PathType Leaf)) {
        throw 'The firewall policy backup referenced by the migration plan is missing. Do not delete rules; create a new option-1 backup.'
    }
    $actualBackupHash = (Get-FileHash -LiteralPath $backupPath -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
    if ($actualBackupHash -cne ([string]$plan.PolicyBackupSHA256).ToUpperInvariant()) {
        throw 'The firewall backup does not match the SHA-256 recorded in the migration plan. Refusing to continue.'
    }
    $plan | Add-Member -NotePropertyName PlanPath -NotePropertyValue $path -Force
    return $plan
}

function ConvertFrom-MigrationPlanCandidates {
    param([Parameter(Mandatory=$true)][object]$Plan)
    $result = New-Object 'System.Collections.Generic.List[object]'
    foreach ($item in @($Plan.Candidates)) {
        $result.Add([pscustomobject]@{
            SourceRule = $item.SourceRule
            Snapshot = $item.Snapshot
            Identity = [string]$item.Identity
            Integrity = $item.Integrity
            SourceFingerprint = [string]$item.SourceFingerprint
            TargetName = [string]$item.TargetName
            TargetDisplayName = [string]$item.TargetDisplayName
            ReviewReason = [string]$item.ReviewReason
            Status = [string]$item.Status
            SourceDisabledByMigration = $false
            Message = [string]$item.Message
            DeletedUtc = [string]$item.DeletedUtc
            CreatedUtc = [string]$item.CreatedUtc
        })
    }
    return $result.ToArray()
}

function Update-MigrationPlanCandidates {
    param([Parameter(Mandatory=$true)][object]$Plan,[Parameter(Mandatory=$true)][object[]]$Candidates)
    $records = @()
    foreach ($candidate in $Candidates) { $records += (ConvertTo-MigrationPlanCandidate -Candidate $candidate) }
    $Plan.Candidates = @($records)
    Save-MigrationPlan -Plan $Plan
}

function Assert-NoPendingMigrationBeforeNewBackup {
    if (-not (Test-Path -LiteralPath $script:MigrationPlanPointerPath -PathType Leaf)) { return }
    $oldPath = (Get-Content -LiteralPath $script:MigrationPlanPointerPath -ErrorAction SilentlyContinue | Select-Object -First 1)
    if ([string]::IsNullOrWhiteSpace([string]$oldPath)) { return }
    if (-not [IO.Path]::IsPathRooted([string]$oldPath)) { $oldPath = Join-Path $script:BackupDir ([string]$oldPath) }
    if (-not (Test-Path -LiteralPath ([string]$oldPath) -PathType Leaf)) { return }
    try { $oldPlan = Get-Content -LiteralPath ([string]$oldPath) -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop }
    catch { throw 'An existing migration plan is unreadable. Preserve the Backups folder and inspect Config\Current-Migration-Plan.txt before creating another backup.' }
    $pending = @($oldPlan.Candidates | Where-Object { ([string]$_.Status) -in @('DELETED_WAITING_ZT_CREATE','ZT_CREATE_ERROR') })
    if (([string]$oldPlan.MigrationStatus) -in @('PRE_DELETE_BACKUP_VERIFIED','ZT_RULE_CREATION_IN_PROGRESS') -or $pending.Length -gt 0) {
        throw 'A previous migration still has deleted source rules waiting for ZT creation, or an interrupted deletion/creation stage. Finish option 3 or restore the recorded .wfw backup before starting a new option-1 plan; a new plan would lose the only source snapshot for those rules.'
    }
}

function Invoke-BackupStage {
    Assert-NoPendingMigrationBeforeNewBackup
    Import-Module NetSecurity -ErrorAction Stop
    $script:Stats = [ordered]@{ Discovered=0; Eligible=0; Created=0; Updated=0; Unchanged=0; RetiredSources=0; Review=0; Skipped=0; Errors=0; Removed=0 }
    $script:HashInventory = New-Object 'System.Collections.Generic.List[object]'
    $script:HashSeen = @{}
    $script:IntegrityAudit = New-Object 'System.Collections.Generic.List[object]'
    Initialize-ExecutableTrustStore

    Write-Status "`nSTAGE 1/3 - BACK UP EXISTING FIREWALL RULES" 'Cyan'
    $backupPath = Export-FirewallBackup
    $backupHash = (Get-FileHash -LiteralPath $backupPath -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()

    Write-Status "`nCapturing application/service rule filters and executable hashes..." 'Cyan'
    $candidates = @(Get-SourceRuleCandidates)
    $newHashes = @($candidates | Where-Object { $null -ne $_.Integrity -and [string]$_.Integrity.IntegrityStatus -eq 'NEW_HASH_REQUIRES_APPROVAL' })
    if ($newHashes.Length -gt 0) {
        Write-Status ("{0} first-seen file hash(es) were found. The current SHA-256 values will be stored in the ZT rules and trusted baseline only after the new ZT rule verifies." -f $newHashes.Length) 'Yellow'
        foreach ($candidate in ($newHashes | Select-Object -First 20)) {
            Write-Host ("  {0} | {1} | SHA256={2}" -f $candidate.SourceRule.DisplayName,$candidate.Integrity.Path,$candidate.Integrity.SHA256)
        }
        $enroll = Read-Host 'To approve first-time enrollment of these displayed hashes, type ENROLL NEW SHA256 HASHES (Enter keeps them on hold)'
        if ($enroll -ceq 'ENROLL NEW SHA256 HASHES') {
            foreach ($candidate in $newHashes) {
                $candidate.Integrity.ApprovalReason = 'Operator approved first-time SHA-256 enrollment in staged migration v2.0.6.'
                $candidate.Integrity.IntegrityStatus = 'OPERATOR_APPROVED_NEW_HASH'
                if ($candidate.Status -eq 'ELIGIBLE_NEW_HASH_PENDING') { $candidate.Status = 'ELIGIBLE' }
            }
            Write-Status 'First-seen executable hashes approved. Baselines are committed only after option 3 verifies the ZT rules.' 'Green'
        }
        else {
            Write-Status 'First-seen executable hashes remain on hold and will not be deleted in stage 2.' 'Yellow'
        }
    }

    $stamp = Get-Date -Format 'yyyyMMdd_HHmmss_fff'
    $planPath = Join-Path $script:BackupDir ("ZT-MigrationPlan_{0}.json" -f $stamp)
    $planCandidates = @()
    foreach ($candidate in $candidates) { $planCandidates += (ConvertTo-MigrationPlanCandidate -Candidate $candidate) }
    $plan = [pscustomobject]@{
        SchemaVersion = 1
        Version = '2.0.6'
        PlanPath = $planPath
        CreatedUtc = (Get-Date).ToUniversalTime().ToString('o')
        PolicyBackupPath = (Join-Path 'Backups' (Split-Path -Leaf $backupPath))
        PolicyBackupSHA256 = $backupHash
        MigrationStatus = 'BACKUP_AND_SNAPSHOT_COMPLETE'
        Candidates = @($planCandidates)
    }
    Save-MigrationPlan -Plan $plan
    Export-ConversionReports -Candidates $candidates

    $captured = @($candidates | Where-Object { $null -ne $_.Snapshot -and -not [string]::IsNullOrWhiteSpace([string]$_.TargetName) }).Length
    $hashReady = @($candidates | Where-Object { $_.Status -in @('ELIGIBLE','APPROVED_BY_OPERATOR') -and $null -ne $_.Integrity -and [string]$_.Integrity.SHA256 -match '^[A-Fa-f0-9]{64}$' }).Length
    $held = @($candidates | Where-Object { $_.Status -notin @('ELIGIBLE','APPROVED_BY_OPERATOR') }).Length
    Write-Status "`nSTAGE 1 COMPLETE" 'Green'
    Write-Status ("Full firewall backup : {0}" -f $backupPath) 'Cyan'
    Write-Status ("Backup SHA-256       : {0}" -f $backupHash) 'Cyan'
    Write-Status ("Rules captured       : {0}" -f $captured) 'White'
    Write-Status ("Currently hash-ready : {0}" -f $hashReady) 'Green'
    Write-Status ("Held/preserved       : {0}" -f $held) 'Yellow'
    Write-Status ("Migration plan       : {0}" -f $planPath) 'Cyan'
    Write-Status 'No firewall rules were deleted or modified in stage 1.' 'Green'
}

function Invoke-DeleteOldRulesStage {
    Import-Module NetSecurity -ErrorAction Stop
    Write-Status "`nSTAGE 2/3 - DELETE OLD APPLICATION/SERVICE RULES" 'Yellow'
    $plan = Read-MigrationPlan
    $candidates = @(ConvertFrom-MigrationPlanCandidates -Plan $plan)

    # This approval menu is retained from the previous release. It approves policy scope, never
    # bypasses executable hashing, path resolution, or fingerprint validation.
    $null = Invoke-BatchSourceApproval -Candidates $candidates

    $allowedHashStates = @('BASELINE_MATCH','APPROVED_NEW_HASH','APPROVED_HASH_CHANGE','OPERATOR_APPROVED_NEW_HASH')
    $deletable = @($candidates | Where-Object {
        $_.Status -in @('ELIGIBLE','APPROVED_BY_OPERATOR','DELETE_ERROR') -and
        $null -ne $_.Snapshot -and $null -ne $_.Integrity -and
        -not [string]::IsNullOrWhiteSpace([string]$_.Integrity.Path) -and
        [string]$_.Integrity.SHA256 -match '^[A-Fa-f0-9]{64}$' -and
        ([string]$_.Integrity.IntegrityStatus) -in $allowedHashStates
    })
    $alreadyDeleted = @($candidates | Where-Object { $_.Status -eq 'DELETED_WAITING_ZT_CREATE' })
    Write-Status ("Rules ready for deletion: {0}; already deleted and waiting for stage 3: {1}; held/preserved: {2}" -f $deletable.Length,$alreadyDeleted.Length,(@($candidates).Length-$deletable.Length-$alreadyDeleted.Length)) 'Cyan'
    if ($deletable.Length -eq 0 -and $alreadyDeleted.Length -eq 0) {
        Update-MigrationPlanCandidates -Plan $plan -Candidates $candidates
        Write-Status 'Nothing is safe to delete. Unresolved hashes, unsupported filters, changed binaries and unapproved rules remain untouched.' 'Yellow'
        return
    }

    # Confirm each source still matches the snapshot captured in stage 1.
    $liveByName = @{}
    $validatedForDelete = New-Object 'System.Collections.Generic.List[object]'
    foreach ($candidate in $deletable) {
        $name = [string]$candidate.SourceRule.Name
        $matches = @(Get-NetFirewallRule -PolicyStore PersistentStore -Name $name -ErrorAction SilentlyContinue | Where-Object { [string]$_.Name -ceq $name })
        if ($matches.Length -eq 0 -and (([string]$plan.MigrationStatus) -in @('PRE_DELETE_BACKUP_VERIFIED','SOURCE_DELETE_STAGE_COMPLETE'))) {
            $candidate.Status = 'DELETED_WAITING_ZT_CREATE'
            $candidate.DeletedUtc = (Get-Date).ToUniversalTime().ToString('o')
            $candidate.Message = 'Source was already absent after a verified pre-delete backup; retained staged snapshot for stage 3.'
            continue
        }
        if ($matches.Length -ne 1) { throw ("Source rule '{0}' is missing or ambiguous. Re-run option 1 to refresh the backup and snapshot." -f $name) }
        if ([string]$matches[0].DisplayName -cne [string]$candidate.SourceRule.DisplayName -or [string]$matches[0].Group -cne [string]$candidate.SourceRule.Group) {
            throw ("Source rule '{0}' display name or group changed since stage 1. Re-run option 1 before deletion." -f $name)
        }
        $currentSnapshot = Get-RuleSnapshot -Rule $matches[0]
        if ((Get-SnapshotFingerprint -Snapshot $currentSnapshot) -cne [string]$candidate.SourceFingerprint) {
            throw ("Source rule '{0}' changed since stage 1. Re-run option 1 and review a new backup before deletion." -f $name)
        }
        Test-ExecutableHashUnchanged -Integrity $candidate.Integrity | Out-Null
        $liveByName[$name] = $matches[0]
        $validatedForDelete.Add($candidate)
    }
    $deletable = $validatedForDelete.ToArray()
    $alreadyDeleted = @($candidates | Where-Object { $_.Status -eq 'DELETED_WAITING_ZT_CREATE' })
    if ($deletable.Length -eq 0 -and $alreadyDeleted.Length -gt 0) {
        $plan.MigrationStatus = 'SOURCE_DELETE_STAGE_COMPLETE'
        Update-MigrationPlanCandidates -Plan $plan -Candidates $candidates
        Write-Status ("All {0} approved source rule(s) are already deleted and waiting for stage 3." -f $alreadyDeleted.Length) 'Green'
        return
    }
    if ($deletable.Length -eq 0) {
        Update-MigrationPlanCandidates -Plan $plan -Candidates $candidates
        Write-Status 'No source rules passed the live fingerprint and executable-hash checks. No rules were deleted.' 'Yellow'
        return
    }

    Write-Status 'The deletion scope is limited to captured Program/Package/Service rules with resolved, approved SHA-256 binaries.' 'Yellow'
    Write-Status 'Windows built-in rules without an app/service identity, unsupported rules, unhashable services and rules held for review will remain.' 'Yellow'
    foreach ($candidate in ($deletable | Sort-Object { [string]$_.SourceRule.Name } | Select-Object -First 30)) {
        Write-Host ("  DELETE: {0} -> planned {1}" -f $candidate.SourceRule.DisplayName,$candidate.TargetName)
    }
    if ($deletable.Length -gt 30) { Write-Host ("  ... and {0} more. See the conversion CSV report." -f ($deletable.Length-30)) }
    $confirmation = Read-Host 'To back up once more and delete these exact source rules, type DELETE DISCOVERED APP SERVICE RULES'
    if ($confirmation -cne 'DELETE DISCOVERED APP SERVICE RULES') {
        Write-Status 'Cancelled; no source rules were deleted.' 'Yellow'
        return
    }

    # Create and verify a second, immediate pre-delete backup. This backup replaces
    # no existing backup and is the restore point recorded in the current plan.
    $preDeleteBackup = Export-FirewallBackup
    $plan.PolicyBackupPath = (Join-Path 'Backups' (Split-Path -Leaf $preDeleteBackup))
    $plan.PolicyBackupSHA256 = (Get-FileHash -LiteralPath $preDeleteBackup -Algorithm SHA256 -ErrorAction Stop).Hash.ToUpperInvariant()
    $plan.MigrationStatus = 'PRE_DELETE_BACKUP_VERIFIED'
    Save-MigrationPlan -Plan $plan

    $deleted = 0
    foreach ($candidate in ($deletable | Sort-Object { [string]$_.SourceRule.Name })) {
        $name = [string]$candidate.SourceRule.Name
        try {
            Remove-NetFirewallRule -InputObject $liveByName[$name] -ErrorAction Stop
            $remaining = @(Get-NetFirewallRule -PolicyStore PersistentStore -Name $name -ErrorAction SilentlyContinue | Where-Object { [string]$_.Name -ceq $name })
            if ($remaining.Length -gt 0) { throw 'Rule still exists after Remove-NetFirewallRule.' }
            $candidate.Status = 'DELETED_WAITING_ZT_CREATE'
            $candidate.DeletedUtc = (Get-Date).ToUniversalTime().ToString('o')
            $candidate.Message = 'Deleted only after verified WFW backup and filter/hash revalidation.'
            $deleted++
            Write-Status ("[DELETED {0}/{1}] {2}" -f $deleted,$deletable.Length,$name) 'Green'
            Update-MigrationPlanCandidates -Plan $plan -Candidates $candidates
        }
        catch {
            $candidate.Status = 'DELETE_ERROR'
            $candidate.Message = $_.Exception.Message
            Write-Status ("[DELETE ERROR] {0}: {1}" -f $name,$_.Exception.Message) 'Red'
            Update-MigrationPlanCandidates -Plan $plan -Candidates $candidates
        }
    }
    $remainingReady = @($candidates | Where-Object { $_.Status -in @('ELIGIBLE','APPROVED_BY_OPERATOR') }).Length
    $plan.MigrationStatus = 'SOURCE_DELETE_STAGE_COMPLETE'
    Update-MigrationPlanCandidates -Plan $plan -Candidates $candidates
    Export-ConversionReports -Candidates $candidates
    $waitingForStage3 = @($candidates | Where-Object { $_.Status -eq 'DELETED_WAITING_ZT_CREATE' }).Length
    Write-Status ("Stage 2 complete: deleted this run {0}; still eligible/not deleted {1}; total waiting for stage 3 {2}." -f $deleted,$remainingReady,$waitingForStage3) 'Cyan'
    Write-Status ("Restore point: {0}" -f $preDeleteBackup) 'Cyan'
    Write-Status 'Run option 3 to create the replacement ZT- rules from the captured snapshots.' 'Green'
}

function Invoke-CreateZTRulesStage {
    Import-Module NetSecurity -ErrorAction Stop
    Write-Status "`nSTAGE 3/3 - CREATE NEW ZT- FIREWALL RULES" 'Cyan'
    $plan = Read-MigrationPlan
    if (([string]$plan.MigrationStatus) -notin @('SOURCE_DELETE_STAGE_COMPLETE','PRE_DELETE_BACKUP_VERIFIED','ZT_RULE_CREATION_IN_PROGRESS','ZT_RULE_CREATION_COMPLETE')) {
        throw 'Stage 2 has not completed. Run option 2 after reviewing the option-1 backup and migration plan.'
    }
    $candidates = @(ConvertFrom-MigrationPlanCandidates -Plan $plan)
    $ready = @($candidates | Where-Object { $_.Status -in @('DELETED_WAITING_ZT_CREATE','ZT_CREATED','ZT_UNCHANGED','ZT_CREATE_ERROR') })
    if ($ready.Length -eq 0) {
        Write-Status 'No deleted/hash-approved source rules are waiting for ZT creation. Review the migration CSV and backup plan.' 'Yellow'
        return
    }
    Write-Status ("Rules queued for creation or verification: {0}" -f $ready.Length) 'White'
    $confirmation = Read-Host 'To implement the replacement ZT- rules, type CREATE ZT RULES'
    if ($confirmation -cne 'CREATE ZT RULES') { Write-Status 'Cancelled; no ZT rules were created.' 'Yellow'; return }

    $plan.MigrationStatus = 'ZT_RULE_CREATION_IN_PROGRESS'
    Save-MigrationPlan -Plan $plan
    $createdCount = 0; $unchangedCount = 0; $errorCount = 0
    foreach ($candidate in $ready) {
        $sourceRule = $candidate.SourceRule
        $targetName = [string]$candidate.TargetName
        try {
            if ([string]::IsNullOrWhiteSpace([string]$candidate.Integrity.Path) -or [string]$candidate.Integrity.SHA256 -notmatch '^[A-Fa-f0-9]{64}$') {
                throw 'No approved file-backed SHA-256 identity is present in the staged plan.'
            }
            Test-ExecutableHashUnchanged -Integrity $candidate.Integrity | Out-Null
            $existing = @(Get-NetFirewallRule -PolicyStore PersistentStore -Name $targetName -ErrorAction SilentlyContinue | Where-Object { [string]$_.Name -ceq $targetName })
            if ($existing.Length -gt 1) { throw ("Duplicate target name exists: {0}" -f $targetName) }
            if ($existing.Length -eq 1 -and [string]$existing[0].Group -cne $script:ManagedGroup) {
                throw ("Target name collision with a rule outside this manager: {0}" -f $targetName)
            }

            $params = New-CloneParameters -Rule $sourceRule -Snapshot $candidate.Snapshot -TargetName $targetName -Integrity $candidate.Integrity
            if ($existing.Length -eq 1 -and (Test-ExistingClone -ExistingRule $existing[0] -SourceSnapshot $candidate.Snapshot -ExpectedDisplayName $candidate.TargetDisplayName)) {
                Set-NetFirewallRule -InputObject $existing[0] -Description ([string]$params.Description) -ErrorAction Stop
                $createdRule = @(Get-NetFirewallRule -PolicyStore PersistentStore -Name $targetName -ErrorAction Stop)
                if ($createdRule.Length -ne 1 -or -not (Test-ExistingClone -ExistingRule $createdRule[0] -SourceSnapshot $candidate.Snapshot -ExpectedDisplayName $candidate.TargetDisplayName)) {
                    throw 'Existing ZT- rule failed final filter verification.'
                }
                $candidate.Status = 'ZT_UNCHANGED'
                $unchangedCount++
                Write-Status ("[VERIFIED EXISTING] {0} | SHA256={1}" -f $targetName,$candidate.Integrity.SHA256) 'Green'
            }
            else {
                if ($existing.Length -eq 1) { Remove-NetFirewallRule -InputObject $existing[0] -ErrorAction Stop }
                New-NetFirewallRule @params | Out-Null
                $createdRule = @(Get-NetFirewallRule -PolicyStore PersistentStore -Name $targetName -ErrorAction Stop)
                if ($createdRule.Length -ne 1 -or -not (Test-ExistingClone -ExistingRule $createdRule[0] -SourceSnapshot $candidate.Snapshot -ExpectedDisplayName $candidate.TargetDisplayName)) {
                    if ($createdRule.Length -gt 0) { $createdRule | Remove-NetFirewallRule -ErrorAction SilentlyContinue }
                    throw 'New ZT- rule did not match its staged source filters; the failed rule was removed.'
                }
                $candidate.Status = 'ZT_CREATED'
                $createdCount++
                Write-Status ("[CREATED] {0} | SHA256={1}" -f $targetName,$candidate.Integrity.SHA256) 'Green'
            }
            Save-TrustedExecutableBaseline -Integrity $candidate.Integrity -RuleName ([string]$sourceRule.Name)
            Save-ZTRuleHashManifest -Candidate $candidate
            $candidate.CreatedUtc = (Get-Date).ToUniversalTime().ToString('o')
        }
        catch {
            $candidate.Status = 'ZT_CREATE_ERROR'
            $candidate.Message = $_.Exception.Message
            $errorCount++
            Write-Status ("[ZT CREATE ERROR] {0}: {1}" -f $sourceRule.Name,$_.Exception.Message) 'Red'
        }
        Update-MigrationPlanCandidates -Plan $plan -Candidates $candidates
    }
    $plan.MigrationStatus = 'ZT_RULE_CREATION_COMPLETE'
    Update-MigrationPlanCandidates -Plan $plan -Candidates $candidates
    Export-ConversionReports -Candidates $candidates
    Write-Status "`nSTAGE 3 SUMMARY" 'Cyan'
    Write-Status ("New ZT- rules created : {0}" -f $createdCount) 'Green'
    Write-Status ("Existing verified     : {0}" -f $unchangedCount) 'Cyan'
    Write-Status ("Creation errors       : {0}" -f $errorCount) $(if ($errorCount -gt 0) { 'Red' } else { 'Green' })
    Write-Status ("Rule/hash manifest    : {0}" -f $script:RuleHashManifestPath) 'Cyan'
    Write-Status 'All created rules use the ZT- name prefix and ZT- display-name prefix. SHA256 is recorded in each rule Description and the per-rule manifest; Windows Firewall does not enforce SHA256 at runtime.' 'Cyan'
}

function Invoke-Convert {
    # Compatibility mode: run the same explicit three-stage flow as the menu.
    Invoke-BackupStage
    Invoke-DeleteOldRulesStage
    Invoke-CreateZTRulesStage
}

function Invoke-Audit {
    Import-Module NetSecurity -ErrorAction Stop
    $rules = @(Get-NetFirewallRule -PolicyStore ActiveStore -ErrorAction Stop | Where-Object {
        ([string]$_.Name).StartsWith($script:RulePrefix,[StringComparison]::OrdinalIgnoreCase)
    })
    Write-Status ("ActiveStore ZT- rules: {0}" -f $rules.Length) 'Cyan'
    foreach ($rule in ($rules | Sort-Object Group,DisplayName)) {
        Write-Host ("{0,-8} {1,-8} {2,-10} {3} | {4}" -f $rule.Enabled,$rule.Direction,$rule.Action,$rule.Name,$rule.DisplayName)
    }
    Write-Status "`nFirewall profile defaults:" 'Cyan'
    Get-NetFirewallProfile | Select-Object Name,Enabled,DefaultInboundAction,DefaultOutboundAction,AllowLocalFirewallRules | Format-Table -AutoSize | Out-Host

    # Include a fresh, read-only integrity scan in every Audit operation.
    $script:Stats = [ordered]@{ Discovered=0; Eligible=0; Created=0; Updated=0; Unchanged=0; RetiredSources=0; Review=0; Skipped=0; Errors=0; Removed=0 }
    $script:HashInventory = New-Object 'System.Collections.Generic.List[object]'
    $script:HashSeen = @{}
    $script:IntegrityAudit = New-Object 'System.Collections.Generic.List[object]'
    Initialize-ExecutableTrustStore
    $candidates = @(Get-SourceRuleCandidates)
    # Audit existing imported ZT rules too, including cases where the original source was disabled.
    $managedRules = @(Get-NetFirewallRule -PolicyStore ActiveStore -ErrorAction Stop | Where-Object {
        ([string]$_.Name).StartsWith($script:RulePrefix,[StringComparison]::OrdinalIgnoreCase) -and
        [string]$_.Group -eq $script:ManagedGroup
    })
    foreach ($managedRule in $managedRules) {
        try {
            $managedSnapshot = Get-RuleSnapshot -Rule $managedRule
            $managedIdentity = @(Get-ApplicationIdentity -Snapshot $managedSnapshot)
            $managedIntegrity = [pscustomobject]@{ Path=''; SHA256=''; BaselineSHA256=''; FileSizeBytes=0L; LastWriteTimeUtc=''; IntegrityStatus='NO_FILE_BACKED_PROGRAM_IDENTITY'; ApprovalReason=''; IdentityType='Unresolved' }
            $managedPrograms = @($managedSnapshot.Program | Where-Object { $_ -ne 'any' })
            $managedServices = @($managedSnapshot.Service | Where-Object { $_ -ne 'any' })
            $managedProgram = ''
            if ($managedPrograms.Length -eq 1) { $managedProgram = [string]$managedPrograms[0] }
            $managedPath = ''
            $managedIdentityType = ''
            if ($managedProgram -and $managedProgram -ne 'system') {
                $managedExpanded = [Environment]::ExpandEnvironmentVariables($managedProgram.Trim().Trim('"'))
                if ($managedExpanded -match '(?i)^\\SystemRoot\\') { $managedExpanded = $managedExpanded -replace '(?i)^\\SystemRoot', $env:SystemRoot }
                if ($managedExpanded -match '^[A-Za-z]:[\\/]' -or $managedExpanded -match '^\\\\') {
                    if ($managedServices.Length -eq 1 -and [IO.Path]::GetFileName($managedExpanded) -ieq 'svchost.exe') {
                        $managedServiceTarget = Get-ServiceHashTarget -ServiceName ([string]$managedServices[0])
                        if ($null -ne $managedServiceTarget) { $managedPath = [string]$managedServiceTarget.Path; $managedIdentityType = [string]$managedServiceTarget.IdentityType }
                    }
                    if (-not $managedPath) { $managedPath = $managedExpanded; $managedIdentityType = 'Program' }
                }
                else { $managedIntegrity.Path = $managedProgram; $managedIntegrity.IntegrityStatus = 'UNRESOLVED_EXECUTABLE_PATH_REQUIRES_REVIEW' }
            }
            elseif ($managedServices.Length -eq 1) {
                $managedServiceTarget = Get-ServiceHashTarget -ServiceName ([string]$managedServices[0])
                if ($null -ne $managedServiceTarget) { $managedPath = [string]$managedServiceTarget.Path; $managedIdentityType = [string]$managedServiceTarget.IdentityType }
                else { $managedIntegrity.IntegrityStatus = 'SERVICE_BINARY_PATH_NOT_RESOLVED_REQUIRES_REVIEW' }
            }
            elseif ($managedProgram -eq 'system') { $managedIntegrity.IntegrityStatus = 'SYSTEM_IDENTITY_NO_FILE_HASH' }
            if ($managedPath) {
                $managedIntegrity = Add-HashInventory -Path $managedPath -RuleName ([string]$managedRule.Name) -RuleDisplayName ([string]$managedRule.DisplayName) -IdentityType $managedIdentityType
            }
            $script:IntegrityAudit.Add([pscustomobject]@{
                ScanUtc = (Get-Date).ToUniversalTime().ToString('o')
                SourceRuleName = [string]$managedRule.Name
                SourceDisplayName = [string]$managedRule.DisplayName
                TargetZTName = [string]$managedRule.Name
                ApplicationIdentity = ($managedIdentity -join '; ')
                ExecutablePath = [string]$managedIntegrity.Path
                BaselineSHA256 = [string]$managedIntegrity.BaselineSHA256
                CurrentSHA256 = [string]$managedIntegrity.SHA256
                FileSizeBytes = [string]$managedIntegrity.FileSizeBytes
                LastWriteTimeUtc = [string]$managedIntegrity.LastWriteTimeUtc
                IntegrityStatus = [string]$managedIntegrity.IntegrityStatus
                ApprovalReason = [string]$managedIntegrity.ApprovalReason
                RuleStatus = 'EXISTING_MANAGED_ZT_RULE_AUDIT'
                ReviewReason = ''
            })
        }
        catch {
            $script:IntegrityAudit.Add([pscustomobject]@{
                ScanUtc = (Get-Date).ToUniversalTime().ToString('o')
                SourceRuleName = [string]$managedRule.Name
                SourceDisplayName = [string]$managedRule.DisplayName
                TargetZTName = [string]$managedRule.Name
                ApplicationIdentity = ''
                ExecutablePath = ''
                BaselineSHA256 = ''
                CurrentSHA256 = ''
                FileSizeBytes = ''
                LastWriteTimeUtc = ''
                IntegrityStatus = 'MANAGED_RULE_AUDIT_ERROR'
                ApprovalReason = ''
                RuleStatus = 'EXISTING_MANAGED_ZT_RULE_AUDIT'
                ReviewReason = $_.Exception.Message
            })
        }
    }
    Export-ConversionReports -Candidates $candidates
    $integrityReview = @($candidates | Where-Object { $_.Status -eq 'REVIEW_REQUIRED' }).Length
    Write-Status ("Executable integrity audit scanned {0} source rules and {1} existing managed ZT rules; {2} source rules require review." -f $candidates.Length,$managedRules.Length,$integrityReview) 'Cyan'
    Write-Status ("Per-ZT-rule hash manifest: {0}" -f $script:RuleHashManifestPath) 'Cyan'
    Write-Status 'Audit is read-only; no firewall settings were changed.' 'Green'
}

function Invoke-RemoveImported {
    Import-Module NetSecurity -ErrorAction Stop
    $rules = @(Get-NetFirewallRule -PolicyStore PersistentStore -ErrorAction Stop | Where-Object {
        ([string]$_.Name).StartsWith($script:RulePrefix,[StringComparison]::OrdinalIgnoreCase) -and
        [string]$_.Group -eq $script:ManagedGroup
    })
    if ($rules.Length -eq 0) { Write-Status 'No managed ZT- rules were found.' 'Yellow'; return }
    Write-Status ("This removes only {0} rules whose Name starts with ZT- and Group exactly matches this manager." -f $rules.Length) 'Yellow'
    Write-Status 'Only this manager-owned ZT- rule family is affected; unrelated rules are preserved.' 'Cyan'
    $confirmation = Read-Host 'Type REMOVE MANAGED ZT RULES to continue'
    if ($confirmation -cne 'REMOVE MANAGED ZT RULES') { Write-Status 'Cancelled; no firewall rules were changed.' 'Yellow'; return }
    $null = Export-FirewallBackup
    $rules | Remove-NetFirewallRule -ErrorAction Stop
    Write-Status ("Removed {0} managed ZT- rules." -f $rules.Length) 'Green'
}

function Invoke-Restore {
    param([string]$RequestedBackup)
    Import-Module NetSecurity -ErrorAction Stop
    if ([string]::IsNullOrWhiteSpace($RequestedBackup)) {
        $available = @(Get-ChildItem -LiteralPath $script:BackupDir -Filter '*.wfw' -File | Sort-Object LastWriteTime -Descending)
        if ($available.Length -eq 0) { throw 'No .wfw backups found in the Backups folder.' }
        Write-Host "`nAvailable full firewall backups:"
        for ($i=0; $i -lt $available.Length; $i++) { Write-Host ("[{0}] {1}" -f ($i+1),$available[$i].Name) }
        $choice = Read-Host 'Enter backup number (0 to cancel)'
        if ($choice -notmatch '^\d+$' -or [int]$choice -eq 0) { Write-Status 'Restore cancelled.' 'Yellow'; return }
        if ([int]$choice -gt $available.Length) { throw 'Invalid backup selection.' }
        $RequestedBackup = $available[[int]$choice-1].FullName
    }
    if (-not (Test-Path -LiteralPath $RequestedBackup -PathType Leaf)) { throw ("Backup file not found: {0}" -f $RequestedBackup) }
    Write-Status 'WARNING: importing a .wfw file replaces the complete local Windows Firewall policy.' 'Yellow'
    Write-Status 'This can overwrite firewall changes made after the selected backup.' 'Yellow'
    $confirm = Read-Host 'Type RESTORE to continue'
    if ($confirm -cne 'RESTORE') { Write-Status 'Restore cancelled.' 'Yellow'; return }
    $currentBackup = Export-FirewallBackup
    Write-Status ("Current policy backed up before restore: {0}" -f $currentBackup) 'Cyan'
    $netsh = Join-Path $env:SystemRoot 'System32\netsh.exe'
    & $netsh advfirewall import $RequestedBackup | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'netsh advfirewall import failed.' }
    Write-Status ("Firewall policy restored from: {0}" -f $RequestedBackup) 'Green'
}

function Invoke-Validation {
    $files = @('ZeroTrust-Firewall.ps1','ZeroTrust-Policy.ps1','Validate-ZeroTrust-Scripts.ps1')
    $failed = $false
    foreach ($file in $files) {
        $path = Join-Path $script:Root $file
        if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
            Write-Status ("[FAIL] Missing script: {0}" -f $path) 'Red'
            $failed = $true
            continue
        }
        $tokens = $null
        $parseErrors = $null
        [System.Management.Automation.Language.Parser]::ParseFile($path,[ref]$tokens,[ref]$parseErrors) | Out-Null
        if ($parseErrors.Length -gt 0) {
            Write-Status ("[FAIL] PowerShell parser: {0}" -f $file) 'Red'
            foreach ($parseError in $parseErrors) {
                Write-Status ("  Line {0}, column {1}: {2}" -f $parseError.Extent.StartLineNumber,$parseError.Extent.StartColumnNumber,$parseError.Message) 'Red'
            }
            $failed = $true
        }
        else { Write-Status ("[PASS] PowerShell 5.1 parser: {0}" -f $file) 'Green' }
    }
    foreach ($file in @('Trusted-Executable-SHA256.csv','Approved-Executable-SHA256.csv','ZT-Rule-Executable-SHA256.csv','Approved-Source-Rules.csv','Approved-Outbound-Allow-Rules.csv')) {
        $configPath = Join-Path $script:ConfigDir $file
        if (Test-Path -LiteralPath $configPath -PathType Leaf) { Write-Status ("[PASS] Config template: {0}" -f $file) 'Green' }
        else { Write-Status ("[FAIL] Missing config template: {0}" -f $file) 'Red'; $failed = $true }
    }
    if ($failed) { throw 'PowerShell/config validation failed.' }
    Write-Status 'All packaged PowerShell scripts and required config templates passed validation.' 'Green'
}

function Show-Menu {
    while ($true) {
        Clear-Host
        Write-Host '================================================================='
        Write-Host ('      ZERO TRUST FIREWALL RULE CONVERTER  v{0}' -f $script:Version)
        Write-Host '================================================================='
        Write-Host 'MIGRATION - RUN THESE THREE OPTIONS IN ORDER:' -ForegroundColor Cyan
        Write-Host '[1] BACK UP EXISTING RULES - full .wfw policy + app/service migration snapshot'
        Write-Host '[2] DELETE OLD APP/SERVICE RULES - only verified, hash-ready, approved snapshot entries'
        Write-Host '[3] IMPLEMENT NEW ZT RULES - recreate from the backup snapshot using ZT- names'
        Write-Host ''
        Write-Host 'TOOLS:' -ForegroundColor Cyan
        Write-Host '[4] Preview discovered application/service rules (read-only)'
        Write-Host '[5] Audit ZT- rules, profiles and executable SHA-256 integrity'
        Write-Host '[6] Export an additional full Windows Firewall backup'
        Write-Host '[7] Restore full firewall policy from a .wfw backup'
        Write-Host '[8] Remove only this manager''s ZT- rules'
        Write-Host '[9] Validate packaged PowerShell scripts'
        Write-Host '[10] Open executable hash baseline / approval files'
        Write-Host '[0] Exit'
        Write-Host ''
        $choice = Read-Host 'Select an option'
        try {
            switch ($choice) {
                '1' { Invoke-BackupStage; Read-Host 'Press Enter to return to menu' | Out-Null }
                '2' { Invoke-DeleteOldRulesStage; Read-Host 'Press Enter to return to menu' | Out-Null }
                '3' { Invoke-CreateZTRulesStage; Read-Host 'Press Enter to return to menu' | Out-Null }
                '4' { Invoke-Preview | Out-Null; Read-Host 'Press Enter to return to menu' | Out-Null }
                '5' { Invoke-Audit; Read-Host 'Press Enter to return to menu' | Out-Null }
                '6' { Export-FirewallBackup | Out-Null; Read-Host 'Press Enter to return to menu' | Out-Null }
                '7' { Invoke-Restore -RequestedBackup $null; Read-Host 'Press Enter to return to menu' | Out-Null }
                '8' { Invoke-RemoveImported; Read-Host 'Press Enter to return to menu' | Out-Null }
                '9' { Invoke-Validation; Read-Host 'Press Enter to return to menu' | Out-Null }
                '10' {
                    Write-Host ("Trusted baseline: {0}" -f $script:ExecutableBaselinePath) -ForegroundColor Cyan
                    Write-Host ("Exact hash approvals: {0}" -f $script:ExecutableApprovalPath) -ForegroundColor Cyan
                    Write-Host ("Per-rule manifest: {0}" -f $script:RuleHashManifestPath) -ForegroundColor Cyan
                    Start-Process notepad.exe -ArgumentList ('"' + $script:ExecutableBaselinePath + '"')
                    Read-Host 'Press Enter to return to menu' | Out-Null
                }
                '0' { return }
                default { Write-Status 'Invalid selection.' 'Yellow'; Start-Sleep -Seconds 1 }
            }
        }
        catch {
            $script:Stats.Errors++
            Write-Status ("`n[ERROR] {0}" -f $_.Exception.Message) 'Red'
            if ($_.ScriptStackTrace) { Write-Status $_.ScriptStackTrace 'DarkGray' }
            Read-Host 'Press Enter to return to menu' | Out-Null
        }
    }
}

if ($Mode -in @('Menu','Preview','Convert','Audit','Backup','DeleteOldRules','CreateZTRules','Restore','RemoveImported') -and -not (Test-IsAdministrator)) {
    try { Start-ElevatedCopy -RequestedMode $Mode -RequestedBackupFile $BackupFile }
    catch { Write-Status ('UAC elevation failed or was cancelled: ' + $_.Exception.Message) 'Red'; exit 2 }
}

foreach ($directory in @($script:LogDir,$script:BackupDir,$script:ReportDir,$script:ConfigDir)) {
    if (-not (Test-Path -LiteralPath $directory -PathType Container)) {
        New-Item -ItemType Directory -Path $directory -Force | Out-Null
    }
}
if (-not (Test-Path -LiteralPath $script:SourceApprovalPath -PathType Leaf)) {
    'Name,Fingerprint,Reason' | Set-Content -LiteralPath $script:SourceApprovalPath -Encoding UTF8
}
$script:SourceApprovals = @(Import-Csv -LiteralPath $script:SourceApprovalPath -ErrorAction Stop)
Initialize-ExecutableTrustStore

if ($Mode -ne 'Validate') {
    try { Start-Transcript -LiteralPath $script:TranscriptPath -Force | Out-Null } catch { }
}
try {
    switch ($Mode) {
        'Menu' { Show-Menu }
        'Preview' { Invoke-Preview | Out-Null }
        'Convert' { Invoke-Convert }
        'DeleteOldRules' { Invoke-DeleteOldRulesStage }
        'CreateZTRules' { Invoke-CreateZTRulesStage }
        'Audit' { Invoke-Audit }
        'Backup' { Invoke-BackupStage }
        'Restore' { Invoke-Restore -RequestedBackup $BackupFile }
        'RemoveImported' { Invoke-RemoveImported }
        'Validate' { Invoke-Validation }
    }
    exit 0
}
catch {
    Write-Status ("[FATAL] {0}" -f $_.Exception.Message) 'Red'
    if ($_.ScriptStackTrace) { Write-Status $_.ScriptStackTrace 'DarkGray' }
    exit 1
}
finally {
    if ($Mode -ne 'Validate') { try { Stop-Transcript | Out-Null } catch { } }
}
