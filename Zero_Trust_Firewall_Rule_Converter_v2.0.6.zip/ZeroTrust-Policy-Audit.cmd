﻿@echo off
setlocal
cd /d "%~dp0"
title Zero Trust Firewall Rule Converter v2.0.6 - Policy Audit
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0ZeroTrust-Policy.ps1" -Mode Audit
pause
